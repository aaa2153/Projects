//
//  MainViewController.m
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "MainViewController.h"
#import "RearViewController.h"
#import "SWRevealViewController.h"



#define METERS_MILE 1609.344
#define METERS_FEET 3.28084

@interface MainViewController ()

-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) from to: (CLLocationCoordinate2D) to;
-(void) centerMap;

@end

@implementation MainViewController

@synthesize sideMenu;
@synthesize mapView;
@synthesize safety;
@synthesize userLocation;
@synthesize destination;
@synthesize stepper;
@synthesize oldValue;
@synthesize nextValue;
@synthesize route;
@synthesize responseObj;
@synthesize alert;
@synthesize responseWaypoints;
@synthesize secureWaypoints;


int zoomcount=0;
float destinationRating;
int flag=0;

- (void)viewDidLoad {
    
    float destinationRating=0;
    
    
    
    self.navigationItem.title=@"SafeWay";
    
    SWRevealViewController *revealController = [self revealViewController];
    
    revealController.title=@"SafeWay";
   
        [self.view addGestureRecognizer:self.revealViewController.panGestureRecognizer];
  
    safety=revealController.safety;
   
    UIImage *btnImage = [UIImage imageNamed:@"reveal-icon.png"];
    
    [sideMenu setImage:btnImage forState:UIControlStateNormal];
    [sideMenu addTarget:revealController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    
    
  //  self.navigationItem.leftBarButtonItem = revealButtonItem;
    
    [super viewDidLoad];
    
    
    
    self.locationManager = [[CLLocationManager alloc] init];
    
    [[self locationManager] setDelegate:self];
    [[self locationManager] setDesiredAccuracy:kCLLocationAccuracyBest];
    [[self locationManager] startUpdatingLocation];
    
    mapView.showsUserLocation = YES;
  //  mapView.mapType = MKMapTypeHybrid;
    mapView.delegate = self;
    
    if ([[self locationManager] respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [[self locationManager] requestWhenInUseAuthorization];
    }
    
   //[self.mapView setCenterCoordinate:self.mapView.userLocation.location.coordinate animated:YES];
    
   double lattitude=self.mapView.userLocation.coordinate.latitude;
   double longitude=self.mapView.userLocation.coordinate.longitude;
    
    
    
    NSLog(@"lat- %f long- %f",lattitude,longitude);
    // [self.mapView addObserver:self forKeyPath:@"myLocation" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:nil];
    // Do any additional setup after loading the view.
    
    secureWaypoints=[[NSMutableArray alloc]init];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/safety/getAllReviews"]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
   // [request setHTTPBody:[self httpBodyForParameters:params]];
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"dataTaskWithRequest error: %@", error);
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            if (statusCode != 200) {
                NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
            }
        }
        
        // If response was JSON (hopefully you designed web service that returns JSON!),
        // you might parse it like so:
        //
        NSError *parseError;
        id responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&parseError];
        if (!responseObject) {
            NSLog(@"JSON parse error: %@", parseError);
            NSLog(@"data : %@", data);
        } else {
            
           
            
             responseWaypoints=responseObject;
            
           
            
            //   [safetyTableView reloadData];
            NSLog(@"*****safety***** = %@", responseObject);
        }
        

    }];
    [task resume];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)showValue {
    double temp = self.stepper.value;
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
       if (object == stepper) {
      //  double oldValue = change[NSKeyValueChangeOldKey];
      //  double newValue = change[NSKeyValueChangeNewKey];
        
        oldValue = change[NSKeyValueChangeOldKey];
        nextValue = change[NSKeyValueChangeNewKey];
      //  double change = newValue - oldValue;
    }
}

- (IBAction)valueChanged:(UIStepper *)sender {
    
   
    
    stepper.minimumValue=0;
    
    [stepper addObserver:self forKeyPath:@"value"
                 options:NSKeyValueObservingOptionOld | NSKeyValueObservingOptionNew
                 context:0];
    

    
  //  double oldValue = change[NSKeyValueChangeOldKey];
  //  double newValue = change[NSKeyValueChangeNewKey];
    
    double value = [sender value];
    
   
    
    if(zoomcount==0){
        
        MKCoordinateRegion region;
        // zoom in
        //Set Zoom level using Span
        MKCoordinateSpan span;
        region.center=mapView.region.center;
        
        span.latitudeDelta=mapView.region.span.latitudeDelta /2.0002;
        span.longitudeDelta=mapView.region.span.longitudeDelta /2.0002;
        region.span=span;
        [mapView setRegion:region animated:TRUE];
        
        zoomcount++;
    }
    
    else{
        
    
    if(oldValue.floatValue<nextValue.floatValue){
        
        MKCoordinateRegion region;
        // zoom in
        //Set Zoom level using Span
        MKCoordinateSpan span;
        region.center=mapView.region.center;
        
        span.latitudeDelta=mapView.region.span.latitudeDelta /2.0002;
        span.longitudeDelta=mapView.region.span.longitudeDelta /2.0002;
        region.span=span;
        [mapView setRegion:region animated:TRUE];
    }
    
    else{
        MKCoordinateRegion region;
        // zoom out
        //Set Zoom level using Span
        MKCoordinateSpan span;
        region.center=mapView.region.center;
        span.latitudeDelta=mapView.region.span.latitudeDelta *2;
        span.longitudeDelta=mapView.region.span.longitudeDelta *2;
        region.span=span;
        [mapView setRegion:region animated:TRUE];

    }
    }
 
}


- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}


- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {

    secureWaypoints=[[NSMutableArray alloc]init];
    [mapView removeAnnotations:[mapView annotations]];
    [mapView removeOverlay:route];
}



- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    
    [searchBar resignFirstResponder];
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [geocoder geocodeAddressString:searchBar.text completionHandler:^(NSArray *placemarks, NSError *error) {
        //Error checking
        
        if(error!=nil){
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Please enter valid address"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            [alert show];
            return;
        }
        
        CLPlacemark *placemark = [placemarks objectAtIndex:0];
        MKCoordinateRegion region;
        region.center.latitude = placemark.region.center.latitude;
        region.center.longitude = placemark.region.center.longitude;
        MKCoordinateSpan span;
        double radius = placemark.region.radius / 1000; // convert to km
        
        NSLog(@"[searchBarSearchButtonClicked] Radius is %f", radius);
     //   span.latitudeDelta = radius / 112.0;
        span.latitudeDelta=50;
        span.longitudeDelta=50;
        region.span = span;
        
        MKPointAnnotation *point = [[MKPointAnnotation alloc] init];
        point.coordinate = region.center;
     //   point.title = @"Where am I?";
       // [point tou];
        
        destination=[[MKPointAnnotation alloc] init];
        
        destination.coordinate=point.coordinate;
        responseObj=nil;
        
        
        NSString *ltt,*lon;
        
        ltt=[NSString stringWithFormat:@"%f",point.coordinate.latitude];
        lon=[NSString stringWithFormat:@"%f",point.coordinate.longitude];
        
        NSDictionary *params = @{@"lattitude":ltt,@"longitude":lon};
        
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/safety/getReview"]];
        [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
        [request setHTTPMethod:@"POST"];
        [request setHTTPBody:[self httpBodyForParameters:params]];
        
        NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
            if (error) {
                NSLog(@"dataTaskWithRequest error: %@", error);
            }
            
            if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
                if (statusCode != 200) {
                    NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
                }
            }
            
            // If response was JSON (hopefully you designed web service that returns JSON!),
            // you might parse it like so:
            //
            NSError *parseError;
            id responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&parseError];
            if (!responseObject) {
                NSLog(@"JSON parse error: %@", parseError);
                NSLog(@"data : %@", data);
            } else {
                
                responseObj=responseObject;
                
                NSArray *jsonData=responseObject;
                
                float rt=0;
                
                for(int i=1;i<[jsonData count];i++)
                {
                    
                    NSNumber *n =[jsonData[i] objectForKey:@"rating"];
                    
                    rt+=[n floatValue];
                    
                    //  for(int i=0;i<[jsonData count];i++)
                    //    {
               //     [comments addObject:[jsonData[i] objectForKey:@"comment"]];
                    
               //     [safetyTableView reloadData];
                    //    }
                }
                if([jsonData count]!=0){
                    destinationRating=rt/[jsonData count];
                    
                    if(destinationRating>0){
                    
                     [point setTitle:[NSString stringWithFormat:@"Rating: %.01f",destinationRating]];
                    }
                    
                    else{
                        
                        [point setTitle:[NSString stringWithFormat:@"Not Rated Yet"]];
                    }

                }
                //   [safetyTableView reloadData];
                NSLog(@"*****safety***** = %@", responseObject);
            }
            
            responseObj=responseObject;
            
            //   [safetyTableView reloadData];
            
            //  NSArray *response=responseObject;
            
            
            // if response was text/html, you might convert it to a string like so:
            //
            // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
            // NSLog(@"responseString = %@", responseString);
        }];
        [task resume];
        
        
       
        
        [self.mapView addAnnotation:point];
        
        [self showRouteFrom:userLocation to:point];
        
        [mapView setRegion:region animated:YES];
    }];
    
    CGPoint touchLocation = [self.gesture locationInView:mapView];
    CLLocationCoordinate2D coordinate = [mapView convertPoint:touchLocation toCoordinateFromView:mapView];
    
  
    
    
  
}


- (NSMutableArray *)decodePolyLine: (NSMutableString *)encoded
{
    
    [encoded replaceOccurrencesOfString:@"\\\\" withString:@"\\" options:NSLiteralSearch range:NSMakeRange(0, [encoded length])];
    NSInteger len = [encoded length];
    NSInteger index = 0;
    NSMutableArray *array = [[NSMutableArray alloc] init];
    NSInteger lat=0;
    NSInteger lng=0;
    while (index < len)
    {
        NSInteger b;
        NSInteger shift = 0;
        NSInteger result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlat = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lat += dlat;
        shift = 0;
        result = 0;
        do
        {
            b = [encoded characterAtIndex:index++] - 63;
            result |= (b & 0x1f) << shift;
            shift += 5;
        } while (b >= 0x20);
        NSInteger dlng = ((result & 1) ? ~(result >> 1) : (result >> 1));
        lng += dlng;
        NSNumber *latitude = [[NSNumber alloc] initWithFloat:lat * 1e-5];
        NSNumber *longitude = [[NSNumber alloc] initWithFloat:lng * 1e-5];
        

        

        //printf("[%f,", [latitude doubleValue]);
        //printf("%f]", [longitude doubleValue]);
        CLLocation *loc = [[CLLocation alloc] initWithLatitude:[latitude floatValue] longitude:[longitude floatValue]];
        [array addObject:loc];
    }
    return array;
}

-(NSArray*) calculateRoutesFrom:(CLLocationCoordinate2D) f to: (CLLocationCoordinate2D) t
{
    
    
    NSString* saddr = [NSString stringWithFormat:@"%f,%f", f.latitude, f.longitude];
    NSString* daddr = [NSString stringWithFormat:@"%f,%f", t.latitude, t.longitude];
    
    NSString* apiUrlStr;
    
    
  /*      if([secureWaypoints count]>0)
        {
            
         apiUrlStr = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&waypoints=%@key=YOUR_API_KEY", saddr, daddr,[NSString stringWithFormat:@"%@", [secureWaypoints objectAtIndex:0]]];
        
        }
        
    
    else{*/
        apiUrlStr = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&key=YOUR_API_KEY", saddr, daddr];

  //  }
    
 //  https://maps.googleapis.com/maps/api/directions/json?origin=Boston,MA&destination=Concord,MA&waypoints=Charlestown,MA|Lexington,MA&key=YOUR_API_KEY
    
    
    NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
    
    NSData *alldata;
    NSMutableDictionary *data1;
    
 //   NSURL *url = [NSURL URLWithString:baseUrl];
    alldata = [[NSData alloc] initWithContentsOfURL:apiUrl];
    
    NSError *err;
    data1 =[NSJSONSerialization JSONObjectWithData:alldata options:NSJSONReadingMutableContainers|NSJSONReadingMutableLeaves error:&err];
    
    NSString *overviewPolyline;
    
    if([[data1 objectForKey:@"routes"] count]>0){
       
        overviewPolyline = [[[[data1 objectForKey:@"routes"] objectAtIndex:0] objectForKey:@"overview_polyline"] objectForKey:@"points"];
    }
    else{
        overviewPolyline=@"";
    }
    
   // NSString *overviewPolyline = [[[[data1 objectForKey:@"routes"] objectAtIndex:0] objectForKey:@"overview_polyline"] objectForKey:@"points"];
    
  //  NSArray *path = [self decodePolyLine:overviewPolyline];
    //NSLog(@"api url: %@", apiUrl);
    NSError* error = nil;
    NSString *apiResponse = [NSString stringWithContentsOfURL:apiUrl encoding:NSASCIIStringEncoding error:&error];
  //  NSString *encodedPoints = [apiResponse stringByMatching:@"points:\\\"([^\\\"]*)\\\"" capture:1L];
    
    NSLog(@"response: %@",apiResponse);
    
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:@"points:\\\"([^\\\"]*)\\\"" options:0 error:NULL];
    NSTextCheckingResult *match = [regex firstMatchInString:apiResponse options:0 range:NSMakeRange(0, [apiResponse length])];
  //  NSString *encodedPoints = [apiResponse substringWithRange:[match rangeAtIndex:1]];
    
    return [self decodePolyLine:[overviewPolyline mutableCopy]];
}

-(void) centerMap
{
    MKCoordinateRegion region;
    CLLocationDegrees maxLat = -90.0;
    CLLocationDegrees maxLon = -180.0;
    CLLocationDegrees minLat = 90.0;
    CLLocationDegrees minLon = 180.0;
    for(int idx = 0; idx < routes.count; idx++)
    {
        CLLocation* currentLocation = [routes objectAtIndex:idx];
        if(currentLocation.coordinate.latitude > maxLat)
            maxLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.latitude < minLat)
            minLat = currentLocation.coordinate.latitude;
        if(currentLocation.coordinate.longitude > maxLon)
            maxLon = currentLocation.coordinate.longitude;
        if(currentLocation.coordinate.longitude < minLon)
            minLon = currentLocation.coordinate.longitude;
    }
    region.center.latitude     = (maxLat + minLat) / 2.0;
    region.center.longitude    = (maxLon + minLon) / 2.0;
    region.span.latitudeDelta = 0.01;
    region.span.longitudeDelta = 0.01;
    
    region.span.latitudeDelta  = ((maxLat - minLat)<0.0)?100.0:(maxLat - minLat);
    region.span.longitudeDelta = ((maxLon - minLon)<0.0)?100.0:(maxLon - minLon);
    [mapView setRegion:region animated:YES];
}

-(void) showRouteFrom: (MKPointAnnotation*) f to:(MKPointAnnotation*) t
{
  //  secureWaypoints=[[NSMutableArray alloc]init];

    if(routes)
    {
        [mapView removeAnnotations:[mapView annotations]];
        [mapView removeOverlay:route];
    }
    
    [mapView addAnnotation:f];
    [mapView addAnnotation:t];
    
    routes = [self calculateRoutesFrom:f.coordinate to:t.coordinate];
    NSInteger numberOfSteps = routes.count;
    
    CLLocationCoordinate2D coordinates[numberOfSteps];
    for (NSInteger index = 0; index < numberOfSteps; index++)
    {
        CLLocation *location = [routes objectAtIndex:index];
        CLLocationCoordinate2D coordinate = location.coordinate;
        coordinates[index] = coordinate;
    }
    MKPolyline *polyLine = [MKPolyline polylineWithCoordinates:coordinates count:numberOfSteps];
    route=polyLine;
    
    
 /*
    
    for(NSInteger index = 0; index < numberOfSteps; index++){
        
        CLLocation *location = [routes objectAtIndex:index];
        CLLocationCoordinate2D coordinate = location.coordinate;
        
        for(int i=0;i<[responseWaypoints count];i++){
            
            NSNumber *ltt=[responseWaypoints[i] objectForKey:@"lattitude"];
            NSNumber *lon=[responseWaypoints[i] objectForKey:@"longitude"];
            
            NSString* saddr = [NSString stringWithFormat:@"%f,%f", ltt.floatValue, lon.floatValue];
            NSString* daddr = [NSString stringWithFormat:@"%f,%f", coordinate.latitude, coordinate.longitude];
            
            NSString *apiUrlStr;
            
            apiUrlStr = [NSString stringWithFormat:@"https://maps.googleapis.com/maps/api/directions/json?origin=%@&destination=%@&key=YOUR_API_KEY", saddr, daddr];
            
       
        //  https://maps.googleapis.com/maps/api/directions/json?origin=Boston,MA&destination=Concord,MA&waypoints=Charlestown,MA|Lexington,MA&key=YOUR_API_KEY
        
        
        NSURL* apiUrl = [NSURL URLWithString:apiUrlStr];
        
        NSData *alldata;
        NSMutableDictionary *data1;
        
        //   NSURL *url = [NSURL URLWithString:baseUrl];
        alldata = [[NSData alloc] initWithContentsOfURL:apiUrl];
        
        NSError *err;
        data1 =[NSJSONSerialization JSONObjectWithData:alldata options:NSJSONReadingMutableContainers|NSJSONReadingMutableLeaves error:&err];
        
        NSString *dist = [[[[[[data1 objectForKey:@"routes"] objectAtIndex:0] objectForKey:@"legs"]objectAtIndex:0] objectForKey:@"distance"] objectForKey:@"text"];
            
            NSRange range= [dist rangeOfString: @" " options: NSBackwardsSearch];
            
            // Take the first substring: from 0 to the space character
            NSNumber* dist1 = (NSNumber*)[dist substringToIndex: range.location];
            
            
            
        if(dist1.floatValue<0.5 && coordinate.latitude!=userLocation.coordinate.latitude && coordinate.longitude!=userLocation.coordinate.longitude && coordinate.latitude!=destination.coordinate.latitude && coordinate.longitude!=destination.coordinate.longitude)
        {
            [secureWaypoints addObject:[NSString stringWithFormat:@"%f,%f",ltt.floatValue,lon.floatValue]];
        }
        }
    }
    
    if([secureWaypoints count]>0){
        
    //    [secureWaypoints addObject:[NSString stringWithFormat:@"%f,%f",46.760261,-73.983851]];
        
        flag=1;
     
    /*    safeRoutes = [self calculateRoutesFrom:f.coordinate to:t.coordinate];
        NSInteger numberOfNewSteps = safeRoutes.count;
        
        CLLocationCoordinate2D coordinates[numberOfNewSteps];
        for (NSInteger index = 0; index < numberOfNewSteps; index++)
        {
            CLLocation *location = [routes objectAtIndex:index];
            CLLocationCoordinate2D coordinate = location.coordinate;
            coordinates[index] = coordinate;
        }
        MKPolyline *safePolyLine = [MKPolyline polylineWithCoordinates:coordinates count:numberOfNewSteps];
        route=polyLine;
        
        [mapView addOverlay:safePolyLine];
  
    }
    */
    
    
    
    

    [mapView addOverlay:polyLine];
    
   // [mapView showsBuildings];
    
    [mapView setNeedsDisplay];

    
    [self centerMap];
    
   /* MKCoordinateRegion region = mapView.region;
    MKCoordinateSpan span;
    span.latitudeDelta = region.span.latitudeDelta*2;
    span.longitudeDelta = region.span.longitudeDelta*2;
    region.span = span;
    [mapView setRegion:region animated:TRUE];*/
}

#pragma mark MKPolyline delegate functions
- (MKOverlayView *)mapView:(MKMapView *)map
            viewForOverlay:(nonnull id<MKOverlay>)overlay {
    
    MKPolylineView *polylineView = [[MKPolylineView alloc] initWithPolyline:overlay];
    
    if(flag==1){
       polylineView.strokeColor = [UIColor greenColor];
    }
    else{
    polylineView.strokeColor = [UIColor blueColor];
    }
    polylineView.lineWidth = 5.0;
    return polylineView;
    
}


-(void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations {
    CLLocation *location = locations.lastObject;
   /* [[self labelLatitude] setText:[NSString stringWithFormat:@"%.6f",
                                   location.coordinate.latitude]];
    [[self labelLongitude] setText:[NSString stringWithFormat:@"%.6f",
                                    location.coordinate.longitude]];
    [[self labelAltitude] setText:[NSString stringWithFormat:@"%.2f feet",
                                   location.altitude*METERS_FEET]];*/
}

- (void)mapView:(MKMapView *)aMapView didUpdateUserLocation:(MKUserLocation *)aUserLocation {
    
    userLocation=[[MKPointAnnotation alloc] init];
    
    MKCoordinateRegion region;
    MKCoordinateSpan span;
    MKPointAnnotation *point;
    
    point=[[MKPointAnnotation alloc] init];
    
    span.latitudeDelta = 50;
    span.longitudeDelta = 50;
    CLLocationCoordinate2D location;
    location.latitude = aUserLocation.coordinate.latitude;
    location.longitude = aUserLocation.coordinate.longitude;
    NSLog(@"lat- %f",location.latitude);
    NSLog(@"long- %f",location.longitude);
    region.span = span;
    region.center = location;
    point.coordinate=location;
    userLocation=point;
    
    [safety setLattitude:[NSNumber numberWithFloat:location.latitude]];
    [safety setLongitude:[NSNumber numberWithFloat:location.longitude]];
    
    [aMapView setRegion:region animated:YES];
}




-(Safety*)location{
    
    Safety *safe=safety;
    
    return safe;
}





@end
