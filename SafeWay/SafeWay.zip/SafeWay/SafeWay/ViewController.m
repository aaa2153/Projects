//
//  ViewController.m
//  SafeWay
//
//  Created by AAA on 3/28/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "ViewController.h"
#import "Reachability.h"
#import "SWRevealViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize email;
@synthesize password;
@synthesize user;
@synthesize alert;
@synthesize responseObj;
@synthesize safety;
@synthesize spinner;

- (void)viewDidLoad {
    
    responseObj=nil;
    
    safety=[[Safety alloc]init];
        
    
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
  //  safety=[[Safety alloc]init];
    
    if ([[segue identifier] isEqualToString:@"login"])
    {
        // Get reference to the destination view controller
        SWRevealViewController *swVC = [segue destinationViewController];
        [swVC setSafety:safety];
        
    }
    
}


- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}


- (IBAction)loginClick:(id)sender {
    
    
    
   // [spinner setHidden:false];
    [spinner startAnimating];
   [[UIApplication sharedApplication] beginIgnoringInteractionEvents];
    
    Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
    if (networkStatus == NotReachable) {
        NSLog(@"There IS NO internet connection");
       
        alert=[[UIAlertView alloc] initWithTitle:@"Alert"
                                         message:@"NO internet connection"
                                        delegate:self
                               cancelButtonTitle:nil
                               otherButtonTitles:@"OK", nil];
        [alert show];
    }
    
    else {

    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
      
   NSDictionary *params = @{@"email":email.text,@"password":password.text};
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/account/login"]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[self httpBodyForParameters:params]];
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"dataTaskWithRequest error: %@", error);
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            if (statusCode != 200) {
                NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
            }
        }
        
        // If response was JSON (hopefully you designed web service that returns JSON!),
        // you might parse it like so:
        //
         NSError *parseError;
         id responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&parseError];
         if (!responseObject) {
             NSLog(@"JSON parse error: %@", parseError);
             NSLog(@"data : %@", data);
             dispatch_async(dispatch_get_main_queue(), ^{
                 [self check];
                 [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
             });
         } else {
             NSLog(@"responseObject = %@", responseObject);
             responseObj=responseObject;
             
             dispatch_async(dispatch_get_main_queue(), ^{
                [self check];
                 [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
             });
          
         }
        
    /*    dispatch_async(dispatch_get_main_queue()) {
            self.tableView.reload()  // this results in all of the `UITableViewDataSource` methods to be called
        }*/
        responseObj=responseObject;
        
      //  NSArray *response=responseObject;
        
        
        // if response was text/html, you might convert it to a string like so:
        //
        // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        // NSLog(@"responseString = %@", responseString);
    }];
    
  //  if(responseObj==nil){
   [task resume];
 //   }
        
        
      /*  if([task state]!=NSURLSessionTaskStateCompleted){
            [task resume];
        }
        else{
            [self check];
        }*/
    
    [[UIApplication sharedApplication] endIgnoringInteractionEvents];
    [spinner stopAnimating];
    
  //  if(responseObj!=nil){
  //      [spinner startAnimating];
  
   //     [spinner startAnimating];
   // }
    
  /*  else{
        
        [spinner startAnimating];
        [task resume];
        if(responseObj!=nil){
        [spinner stopAnimating];
        }
        
        else{
            [task resume];
        }
       
    }*/
    }
}


-(void)check{
    

    if([email.text isEqualToString:[responseObj objectForKey:@"email"]])
    {
        
        [self performSegueWithIdentifier:@"login" sender:self];
    }
    
    else{
        
        alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                           message:@"Invalid Email/Password"
                                          delegate:self
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
        [alert show];
        
    }
   }


@end
