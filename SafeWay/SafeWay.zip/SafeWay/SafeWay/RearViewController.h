//
//  RearViewController.h
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Safety.h"
#import "HCSStarRatingView.h"

@interface RearViewController : UITableViewController

@property (nonatomic, retain) IBOutlet UITableView *rearTableView;
@property(readwrite,retain) Safety *safety;

@property(readwrite,retain) NSDictionary *responseObj;



@property (readwrite,retain) NSMutableArray *comments;

@end
