//
//  SafetyViewController.m
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "SafetyViewController.h"

@interface SafetyViewController ()

@end

@implementation SafetyViewController

@synthesize safety;
@synthesize responseObj;
@synthesize rating;
@synthesize comments;
@synthesize safetyTableView;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title=@"Location";
    
  //  rating = [HCSStarRatingView new];
  //  starRatingView.value = 4;
    rating.tintColor = [UIColor blueColor];
    rating.allowsHalfStars = YES;
  //  rating;
  //  comments=[[NSMutableArray alloc]init];
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    NSString *ltt,*lon;
    
    ltt=[NSString stringWithFormat:@"%@",safety.lattitude];
    lon=[NSString stringWithFormat:@"%@",safety.longitude];
    
    NSDictionary *params = @{@"lattitude":ltt,@"longitude":lon};
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/safety/getReview"]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[self httpBodyForParameters:params]];
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"dataTaskWithRequest error: %@", error);
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            if (statusCode != 200) {
                NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
            }
        }
        
        // If response was JSON (hopefully you designed web service that returns JSON!),
        // you might parse it like so:
        //
        NSError *parseError;
        id responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&parseError];
        if (!responseObject) {
            NSLog(@"JSON parse error: %@", parseError);
            NSLog(@"data : %@", data);
        } else {
            
            responseObj=responseObject;
            
            NSArray *jsonData=responseObject;
            
            float rt=0;
            
            for(int i=0;i<[jsonData count];i++)
            {
            
            NSNumber *n =[jsonData[i] objectForKey:@"rating"];
            
            rt+=[n floatValue];
            
          //  for(int i=0;i<[jsonData count];i++)
        //    {
              [safetyTableView reloadData];
        //    }
            }
            if([jsonData count]!=0){
            rating.value=rt/[jsonData count];
            }
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
         //   [safetyTableView reloadData];
            NSLog(@"*****safety***** = %@", responseObject);
        }
        
        responseObj=responseObject;
        
     //   [safetyTableView reloadData];
        
        //  NSArray *response=responseObject;
        
        
        // if response was text/html, you might convert it to a string like so:
        //
        // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        // NSLog(@"responseString = %@", responseString);
    }];
    [task resume];
    
    
    [safetyTableView reloadData];
    
  //  [self.view addSubview:rating];

    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    
    
    
    
    
   // [safetyTableView reloadData];
}


- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Incomplete implementation, return the number of sections
    return 3;
}

-(NSString*)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    
    
    
    if(section==0)
        return @"Rating";
    else if(section==1)
        return @"Comments";
    else
        return @"Media";
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    if(section==0)
        return 1;
    else if(section==1)
        return [comments count];
    else
        return 0;

}





- (UITableViewCell *)tableView:(UITableView *)tView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellR=@"cellR";
    static NSString *cellC=@"cellC";
    static NSString *cellM=@"cellM";
    
    
    if(indexPath.section==0)
    {
        UITableViewCell *cell = [safetyTableView dequeueReusableCellWithIdentifier:cellR];
        
        if(cell==nil){
            
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellR];
        }
        
        
     //   [cell setMaskView:rating];
        
        [cell setAccessoryView:rating];
        
        // Set the loaded data to the appropriate cell labels.
        
        
        return cell;
        
    }
    
    if(indexPath.section==1)
    {
        UITableViewCell *cell = [safetyTableView dequeueReusableCellWithIdentifier:cellC];
        
        if(cell==nil){
            
            cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellC];
        }
        
        for(int i=0;i<[comments count];i++)
        {
            if(i==indexPath.row)
            {
                cell.textLabel.text = [comments objectAtIndex:i];
                
           //     cell.imageView.image = [images objectAtIndex:6];
                
            }
        }
        
        // Set the loaded data to the appropriate cell labels.
        
        
        return cell;
        
    }


 
    return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

@end
