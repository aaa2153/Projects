//
//  CurrentLocationViewController.m
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "CurrentLocationViewController.h"
#import "HCSStarRatingView.h"
#import "Reachability.h"


@interface CurrentLocationViewController ()

@end

@implementation CurrentLocationViewController

@synthesize comment;
@synthesize rating;
@synthesize alert;
@synthesize safety;


- (void)viewDidLoad {
    
  //  safety =[[Safety alloc]init];
    
    HCSStarRatingView *starRatingView = [HCSStarRatingView new];
    starRatingView.maximumValue = 10;
    starRatingView.minimumValue = 0;
    starRatingView.value = 4;
    starRatingView.tintColor = [UIColor redColor];
    starRatingView.allowsHalfStars = YES;
    starRatingView.emptyStarImage = [[UIImage imageNamed:@"heart-empty"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    starRatingView.filledStarImage = [[UIImage imageNamed:@"heart-full"] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    [starRatingView addTarget:self action:@selector(didChangeValue:) forControlEvents:UIControlEventValueChanged];
    [self.view addSubview:starRatingView];
    
    // auto layout
    starRatingView.translatesAutoresizingMaskIntoConstraints = NO;
  /*  [[NSLayoutConstraint constraintWithItem:starRatingView
                                  attribute:NSLayoutAttributeTop
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:self.lastRatingTitleLabel
                                  attribute:NSLayoutAttributeBottom
                                 multiplier:1.f
                                   constant:8.f] setActive:YES];*/
    [[NSLayoutConstraint constraintWithItem:starRatingView
                                  attribute:NSLayoutAttributeCenterX
                                  relatedBy:NSLayoutRelationEqual
                                     toItem:self.view
                                  attribute:NSLayoutAttributeCenterX
                                 multiplier:1.f
                                   constant:0.f] setActive:YES];
    [[NSLayoutConstraint constraintWithItem:starRatingView
                                  attribute:NSLayoutAttributeWidth
                                  relatedBy:NSLayoutRelationLessThanOrEqual
                                     toItem:self.view
                                  attribute:NSLayoutAttributeWidth
                                 multiplier:.9f
                                   constant:0.f] setActive:YES];
    
    comment.layer.borderWidth = 5.0f;
    comment.layer.borderColor = [[UIColor grayColor] CGColor];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



- (IBAction)didChangeValue:(HCSStarRatingView *)sender {
    NSLog(@"Changed rating to %.1f", sender.value);
    rating= sender;
}

- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}


- (IBAction)btnSubmitClick:(id)sender {
    
    if(rating.value==0){
        
        alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                           message:@"Please enter rating"
                                          delegate:self
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
        
        [alert show];
        
        
    }
    
    else{
        
                
        [safety setRating:[NSNumber numberWithFloat:rating.value]];
        [safety setComment:comment.text];
        
        
       // [safety setLattitude:[NSNumber numberWithFloat:0.0]];
     //   [safety setLongitude:[NSNumber numberWithFloat:0.0]];
        

        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            NSLog(@"There IS NO internet connection");
            //   UIAlertView *alert;
            alert=[[UIAlertView alloc] initWithTitle:@"Alert"
                                             message:@"NO internet connection"
                                            delegate:self
                                   cancelButtonTitle:nil
                                   otherButtonTitles:@"OK", nil];
            [alert show];
        }
        
        else {
            
            NSString *rt,*ltt,*lon;
            
            rt=[NSString stringWithFormat:@"%@",safety.rating];
            ltt=[NSString stringWithFormat:@"%@",safety.lattitude];
            lon=[NSString stringWithFormat:@"%@",safety.longitude];
            
            
            NSDictionary *params = @{@"rating": rt, @"comment": safety.comment,@"lattitude":ltt,@"longitude":lon};
            
            
        [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/safety/addReview"]];
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[self httpBodyForParameters:params]];
            
            NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                if (error) {
                    NSLog(@"dataTaskWithRequest error: %@", error);
                }
                
                if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                    NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
                    [alert show];
                    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
                    if (statusCode != 200) {
                        NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
                    }
                }
                
                // If response was JSON (hopefully you designed web service that returns JSON!),
                // you might parse it like so:
                //
                // NSError *parseError;
                // id responseObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
                // if (!responseObject) {
                //     NSLog(@"JSON parse error: %@", parseError);
                // } else {
                //     NSLog(@"responseObject = %@", responseObject);
                // }
                
                // if response was text/html, you might convert it to a string like so:
                //
                // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"responseString = %@", responseString);
            }];
            [task resume];
            
            
            
            
            //  ViewController *login =[[ViewController alloc]init];
            //  [login setUser:user];
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Thanks for your review"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            
          //  [self performSegueWithIdentifier:@"loginView" sender:self];
        }
    }
    
}

- (IBAction)btnAttchClick:(id)sender {
}
@end
