//
//  SafetyViewController.h
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Safety.h"
#import "HCSStarRatingView.h"

@interface SafetyViewController : UITableViewController
//@property (weak, nonatomic) IBOutlet UINavigationBar *navBarSafety;

@property (nonatomic, retain) IBOutlet UITableView *safetyTableView;
@property(readwrite,retain) Safety *safety;
@property(readwrite,retain) NSDictionary *responseObj;
@property (weak, nonatomic) IBOutlet HCSStarRatingView *rating;


@property (readwrite,retain) NSMutableArray *comments;

@end
