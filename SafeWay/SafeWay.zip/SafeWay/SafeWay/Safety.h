//
//  Safety.h
//  SafeWay
//
//  Created by AAA on 4/3/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "User.h"

@interface Safety : NSObject

@property(readwrite,retain) NSNumber *rating;
@property(readwrite,retain) NSString *comment;
@property(readwrite,retain) NSString *media;
@property(readwrite,retain) NSNumber *lattitude;
@property(readwrite,retain) NSNumber *longitude;
@property(readwrite,retain) User *user;

@end
