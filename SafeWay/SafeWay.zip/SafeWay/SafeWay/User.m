//
//  User.m
//  SafeWay
//
//  Created by AAA on 4/3/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "User.h"

@implementation User

@synthesize firstName;
@synthesize lastName;
@synthesize mobileNumber;
@synthesize email;
@synthesize password;


@end
