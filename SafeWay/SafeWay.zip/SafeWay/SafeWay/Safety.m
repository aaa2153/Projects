//
//  Safety.m
//  SafeWay
//
//  Created by AAA on 4/3/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "Safety.h"

@implementation Safety

@synthesize rating;
@synthesize comment;
@synthesize media;
@synthesize lattitude;
@synthesize longitude;

@end
