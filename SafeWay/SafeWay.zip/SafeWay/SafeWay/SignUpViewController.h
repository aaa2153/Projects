//
//  SignUpViewController.h
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"

@interface SignUpViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITextField *firstName;
@property (weak, nonatomic) IBOutlet UITextField *lastName;
@property (weak, nonatomic) IBOutlet UITextField *mobileNumber;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *confirmPassword;
@property (weak, nonatomic) IBOutlet UIButton *btnSignup;

@property (nonatomic, retain) UIAlertView *alert;
@property(readwrite,retain) User *user;

- (IBAction)signupClick:(id)sender;


@end
