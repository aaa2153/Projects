//
//  RearViewController.m
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "RearViewController.h"
#import "CurrentLocationViewController.h"
#import "SafetyViewController.h"
#import "SWRevealViewController.h"
//#import "FrontViewController.h"
//#import "MapViewController.h"

@interface RearViewController()
{
    NSInteger _presentedRow;
}

@end

@implementation RearViewController

@synthesize safety;

@synthesize rearTableView = _rearTableView;

@synthesize responseObj;

@synthesize comments;


#pragma mark - View lifecycle


- (void)viewDidLoad
{
    [super viewDidLoad];
    

   
     comments=[[NSMutableArray alloc]init];
    
    self.title = NSLocalizedString(@"Rear View", nil);
    
    SWRevealViewController *revealController = [self revealViewController];
    
    safety=revealController.safety;
    
    
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    
    NSString *ltt,*lon;
    
    ltt=[NSString stringWithFormat:@"%@",safety.lattitude];
    lon=[NSString stringWithFormat:@"%@",safety.longitude];
    
    NSDictionary *params = @{@"lattitude":ltt,@"longitude":lon};
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/safety/getReview"]];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[self httpBodyForParameters:params]];
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error) {
            NSLog(@"dataTaskWithRequest error: %@", error);
        }
        
        if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            if (statusCode != 200) {
                NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
            }
        }
        
        // If response was JSON (hopefully you designed web service that returns JSON!),
        // you might parse it like so:
        //
        NSError *parseError;
        id responseObject = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&parseError];
        if (!responseObject) {
            NSLog(@"JSON parse error: %@", parseError);
            NSLog(@"data : %@", data);
        } else {
            
            responseObj=responseObject;
            
            NSArray *jsonData=responseObject;
            
            float rt=0;
            
            for(int i=0;i<[jsonData count];i++)
            {
                
                NSNumber *n =[jsonData[i] objectForKey:@"rating"];
                
                rt+=[n floatValue];
                
                //  for(int i=0;i<[jsonData count];i++)
                //    {
                [comments addObject:[jsonData[i] objectForKey:@"comment"]];
                
               
                //    }
            }
            
            [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
            //   [safetyTableView reloadData];
            NSLog(@"*****safety***** = %@", responseObject);
        }
        
        responseObj=responseObject;
        
        //   [safetyTableView reloadData];
        
        //  NSArray *response=responseObject;
        
        
        // if response was text/html, you might convert it to a string like so:
        //
        // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        // NSLog(@"responseString = %@", responseString);
    }];
    [task resume];
    

}


- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}




#pragma marl - UITableView Data Source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([[segue identifier] isEqualToString:@"rateLocation"])
    {
        // Get reference to the destination view controller
       CurrentLocationViewController *clVC = [segue destinationViewController];
        [clVC setSafety:safety];
        
    }
    
    if ([[segue identifier] isEqualToString:@"yourSafety"])
    {
        // Get reference to the destination view controller
        SafetyViewController *sVC = [segue destinationViewController];
        
    //    [sVC setRating:rating];
        [sVC setComments:comments];
        [sVC setSafety:safety];
        
    }

    
    
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    NSInteger row = indexPath.row;
    
    if (nil == cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier];
    }
    
    NSString *text = nil;
    if (row == 1)
    {
        text = @"Your Safety";
    }
    else if (row == 2)
    {
        text = @"Rate Location";
    }
    else if (row == 3)
    {
        text = @"Logout";
    }
    
    
    cell.textLabel.text = NSLocalizedString( text,nil );
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Grab a handle to the reveal controller, as if you'd do with a navigtion controller via self.navigationController.
    SWRevealViewController *revealController = self.revealViewController;
    
    // selecting row
    NSInteger row = indexPath.row;
    
    // if we are trying to push the same row or perform an operation that does not imply frontViewController replacement
    // we'll just set position and return
    
 /*   if ( row == _presentedRow )
    {
        [revealController setFrontViewPosition:FrontViewPositionLeft animated:YES];
        return;
    }
    else if (row == 2)
    {
        [revealController setFrontViewPosition:FrontViewPositionRightMost animated:YES];
        return;
    }
    else if (row == 3)
    {
        [revealController setFrontViewPosition:FrontViewPositionRight animated:YES];
        return;
    }*/
    
    // otherwise we'll create a new frontViewController and push it with animation
    
    UIViewController *newFrontController = nil;
    
    if (row == 1)
    {
      //  newFrontController = [[FrontViewController alloc] init];
        [self performSegueWithIdentifier:@"yourSafety" sender:self];
    }
    
    else if (row == 2)
    {
      //  newFrontController = [[MapViewController alloc] init];
        [self performSegueWithIdentifier:@"rateLocation" sender:self];
    }
    
    else if (row == 3)
    {
        //  newFrontController = [[MapViewController alloc] init];
        [self performSegueWithIdentifier:@"login" sender:self];
    }
    
 //   UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:newFrontController];
 //   [revealController pushFrontViewController:navigationController animated:YES];
    
    _presentedRow = row;  // <- store the presented row
}





@end
