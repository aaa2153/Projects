//
//  MainViewController.h
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>



#import "Safety.h"

@protocol currentLocation <NSObject>

-(Safety*)location;

@end

@interface MainViewController: UIViewController<MKMapViewDelegate,CLLocationManagerDelegate,MKOverlay>
{
    NSArray* routes;
    NSArray* safeRoutes;
    BOOL isUpdatingRoutes;
}

@property (weak, nonatomic) IBOutlet UIButton *sideMenu;
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property (nonatomic, strong) CLLocationManager *locationManager;
@property(readwrite,retain) Safety *safety;
@property (nonatomic, retain) UIAlertView *alert;
@property(readwrite,retain) NSDictionary *responseObj;
@property(readwrite,retain) NSArray *responseWaypoints;
@property(readwrite,retain) NSMutableArray *secureWaypoints;
@property (weak, nonatomic) IBOutlet UISearchBar *searchLocation;

@property (weak, nonatomic) IBOutlet UIStepper *stepper;
- (IBAction)valueChanged:(id)sender;


@property (weak, nonatomic) UITapGestureRecognizer *gesture;
@property (readwrite, retain) MKPointAnnotation *userLocation;
@property (readwrite, retain) MKPointAnnotation *destination;
@property (readwrite, retain) MKPolyline *route;
@property (readwrite, retain) NSNumber *oldValue;
@property (readwrite, retain) NSNumber *nextValue;

-(void) showRouteFrom: (MKPointAnnotation*) f to:(MKPointAnnotation*) t;

@end
