//
//  User.h
//  SafeWay
//
//  Created by AAA on 4/3/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject

@property(readwrite,retain) NSString *firstName;
@property(readwrite,retain) NSString *lastName;
@property(readwrite,retain) NSString *mobileNumber;
@property(readwrite,retain) NSString *email;
@property(readwrite,retain) NSString *password;

@end
