//
//  SignUpViewController.m
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import "SignUpViewController.h"
#import "User.h"
#import "Reachability.h"

@interface SignUpViewController ()


@end

@implementation SignUpViewController

@synthesize firstName;
@synthesize lastName;
@synthesize mobileNumber;
@synthesize email;
@synthesize password;
@synthesize confirmPassword;
@synthesize alert;
@synthesize user;

- (void)viewDidLoad {
    
    user =[[User alloc]init];
    
    self.navigationItem.title=@"Sign Up";
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([[segue identifier] isEqualToString:@"loginView"])
    {
        // Get reference to the destination view controller
        ViewController *loginVC = [segue destinationViewController];
        [loginVC setUser:user];
        
    }
    
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (NSString *)percentEscapeString:(NSString *)string {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~"];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:allowed];
}


- (NSData *)httpBodyForParameters:(NSDictionary *)parameters {
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [parameters enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", [self percentEscapeString:key], [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}






- (IBAction)signupClick:(id)sender {
    
    
    
    NSString *alpha = @"[a-zA-Z]+";
    NSString *email1 = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}";
    NSString *mobile = @"[0-9]{10}";
    NSString *password1 = @"[a-zA-Z0-9]{3,8}";
    NSPredicate *regexTestAlpha = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", alpha];
    NSPredicate *regexTestEmail = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", email1];
    NSPredicate *regexTestMobile = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobile];
    NSPredicate *regexTestPassword = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", password1];
    
    if([firstName.text isEqualToString:@"" ] ||[lastName.text isEqualToString: @""] || [mobileNumber.text isEqualToString:@""] || [email.text isEqualToString:@""] ||[password.text isEqualToString:@""] || [confirmPassword.text isEqualToString:@""]){
        
        
        
        alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                           message:@"Please enter all details"
                                          delegate:self
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
        
        [alert show];
        
        
    }

    
       else if(![regexTestAlpha evaluateWithObject:firstName.text] || ![regexTestAlpha evaluateWithObject:lastName.text])
        {
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Please enter only alphabets in firstname and lastname"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            [alert show];
 
        }
        
        else if(![regexTestEmail evaluateWithObject:email.text]){
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Please enter valid email"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            [alert show];
            
        }
        
        else if(![regexTestMobile evaluateWithObject:mobileNumber.text]){
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Please enter valid Mobile Number"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            [alert show];
            
        }
        
        else if(![regexTestPassword evaluateWithObject:password.text]){
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Password should be between 3 to 8 charactors"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            [alert show];
            
        }
        
        else if(![password.text isEqualToString:confirmPassword.text]){
            
            alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                               message:@"Passwords should match"
                                              delegate:self
                                     cancelButtonTitle:nil
                                     otherButtonTitles:@"OK", nil];
            
            [alert show];
            
        }



       
    else{
        
        
        [user setFirstName:firstName.text];
        [user setLastName:lastName.text];
        [user setMobileNumber:mobileNumber.text];
        [user setEmail:email.text];
        [user setPassword:password.text];
        
        Reachability *networkReachability = [Reachability reachabilityForInternetConnection];
        NetworkStatus networkStatus = [networkReachability currentReachabilityStatus];
        if (networkStatus == NotReachable) {
            NSLog(@"There IS NO internet connection");
         //   UIAlertView *alert;
            alert=[[UIAlertView alloc] initWithTitle:@"Alert"
                                             message:@"NO internet connection"
                                            delegate:self
                                   cancelButtonTitle:nil
                                   otherButtonTitles:@"OK", nil];
            [alert show];
        }
        
        else {
            
            NSDictionary *params = @{@"firstname": user.firstName, @"lastname": user.lastName,@"mobileNumber":user.mobileNumber,@"email":user.email,@"password":user.password};
            
            NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://safeway.eastus.cloudapp.azure.com:24457/SafeWay/account/register"]];
            [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
            [request setHTTPMethod:@"POST"];
            [request setHTTPBody:[self httpBodyForParameters:params]];
            
            NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
                if (error) {
                    NSLog(@"dataTaskWithRequest error: %@", error);
                }
                
                if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
                    NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
                    if (statusCode != 200) {
                        NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
                    }
                }
                
                // If response was JSON (hopefully you designed web service that returns JSON!),
                // you might parse it like so:
                //
                // NSError *parseError;
                // id responseObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
                // if (!responseObject) {
                //     NSLog(@"JSON parse error: %@", parseError);
                // } else {
                //     NSLog(@"responseObject = %@", responseObject);
                // }
                
                // if response was text/html, you might convert it to a string like so:
                //
                // NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                // NSLog(@"responseString = %@", responseString);
            }];
            [task resume];
            
            

        
      //  ViewController *login =[[ViewController alloc]init];
      //  [login setUser:user];
        
        alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                           message:@"Account Created Successfully"
                                          delegate:self
                                 cancelButtonTitle:nil
                                 otherButtonTitles:@"OK", nil];
        [alert show];
        
        [self performSegueWithIdentifier:@"loginView" sender:self];
    }

}
}
@end
