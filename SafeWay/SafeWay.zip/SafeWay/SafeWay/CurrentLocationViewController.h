//
//  CurrentLocationViewController.h
//  SafeWay
//
//  Created by AAA on 3/29/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HCSStarRatingView.h"
#import "Safety.h"
#import "MainViewController.h"


@interface CurrentLocationViewController : UIViewController<currentLocation>
@property (weak, nonatomic) IBOutlet UITextView *comment;
@property (weak, nonatomic) IBOutlet UIButton *btnAttach;
@property (readwrite,retain) HCSStarRatingView  *rating;
@property (nonatomic, retain) UIAlertView *alert;
@property(readwrite,retain) Safety *safety;

@property (weak, nonatomic) IBOutlet UIButton *btnSubmit;

- (IBAction)btnSubmitClick:(id)sender;
- (IBAction)btnAttchClick:(id)sender;

@end
