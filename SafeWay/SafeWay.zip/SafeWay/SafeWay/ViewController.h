//
//  ViewController.h
//  SafeWay
//
//  Created by AAA on 3/28/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "User.h"
#import "Safety.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *login;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *spinner;

@property(readwrite,retain) User *user;
@property(readwrite,retain) Safety *safety;
@property(readwrite,retain) NSDictionary *responseObj;
@property (nonatomic, retain) UIAlertView *alert;

- (IBAction)loginClick:(id)sender;

@end

