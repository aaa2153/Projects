//
//  AppDelegate.h
//  SafeWay
//
//  Created by AAA on 3/28/17.
//  Copyright © 2017 AAA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

