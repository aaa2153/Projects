package com.neu.sw.controller;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.neu.sw.dao.SafetyDAO;
import com.neu.sw.dao.UserDAO;
import com.neu.sw.exception.SafetyException;
import com.neu.sw.pojo.Safety;
import com.neu.sw.pojo.User;
//import com.neu.hmf.validator.UserValidator;

@Controller
@RequestMapping("/safety/*")
public class SafetyController {

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;
	
	@Autowired
	@Qualifier("safetyDao")
	SafetyDAO safetyDao;

//	@Autowired
//	@Qualifier("userValidator")
//	UserValidator validator;

//	@InitBinder
//	private void initBinder(WebDataBinder binder) {
//		binder.setValidator(validator);
//	}
	
//	@RequestMapping(value = "/account/login", method = RequestMethod.GET)
//	protected String goToUserHome(HttpServletRequest request) throws Exception {
//		return "login";
//	}
//	
//	@RequestMapping(value = "/account/logout", method = RequestMethod.GET)
//	protected String logout(HttpServletRequest request) throws Exception {
//		HttpSession session = (HttpSession) request.getSession();
//		session.invalidate();
//		return "index";
//	}
	
	
	@RequestMapping(value = "/safety/getReview", method = RequestMethod.POST, produces = "application/json")
	protected @ResponseBody String loginUser(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		boolean loggedIn=true;
		
		try {

			System.out.print("loginUser");

		//	User u = userDao.get(request.getParameter("email"), request.getParameter("password"));
			
			List<Safety> s= safetyDao.get(Float.parseFloat(request.getParameter("lattitude")), Float.parseFloat(request.getParameter("longitude")));
			
			if(s == null){
				loggedIn=false;
				System.out.println("This location has not been rated yet");
				session.setAttribute("errorMessage", "This location has not been rated yet");
				return "redirect:/";
			}
			
		//	JSONArray jsonArray = new JSONArray(s);
			
			Gson gson = new Gson();

			String jsonInString = gson.toJson(s);
			
		//	System.out.println(s.get(1).getComment());
			return jsonInString;
			
		} catch (SafetyException e) {
			System.out.println("Exception: " + e.getMessage());
			session.setAttribute("errorMessage", "error while getting data");
			return "redirect:/";
		}
		
		

	}
	

	
	@RequestMapping(value = "/safety/addReview", method = RequestMethod.POST)
	protected ModelAndView addReview(HttpServletRequest request) throws Exception {

		HttpSession session=request.getSession();
		boolean success=false;
	//	validator.validate(user, result);

//		if (result.hasErrors()) {
//			return new ModelAndView("error", "user", user);
//		}

		try {

			System.out.print("add review");

			User u = (User)session.getAttribute("user");
			
			Safety s = safetyDao.addReview(request, u);
			
			request.getSession().setAttribute("user", u);
			
			success=true;
			session.setAttribute("success", success);
			return new ModelAndView("redirect:/");

		} catch (SafetyException e) {
			System.out.println("Exception: " + e.getMessage());
			return new ModelAndView("redirect:/", "errorMessage", "error while login");
		}
	}

}
