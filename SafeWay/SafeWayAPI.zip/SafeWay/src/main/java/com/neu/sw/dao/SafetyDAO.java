package com.neu.sw.dao;



import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.json.JSONArray;
import org.json.JSONObject;

import com.neu.sw.exception.SafetyException;
import com.neu.sw.exception.UserException;
import com.neu.sw.pojo.Safety;
import com.neu.sw.pojo.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


public class SafetyDAO extends DAO {

	public SafetyDAO() {
	}

	public List<Safety> get(float lattitude, float longitude) throws SafetyException {
		try {
			begin();
			Query q1 = getSession().createQuery("from Safety where lattitude = :lattitude and longitude = :longitude");
			Query q = getSession().createQuery("from Safety");

		//	String hashedPassword = passwordEncoder.encode(password);
			q1.setFloat("lattitude", lattitude);
			q1.setFloat("longitude", longitude);
				
			Safety safety1 = (Safety) q1.uniqueResult();
			
			List<Safety> safetyList= q.list();
			
			List<Safety> newSafetyList = new ArrayList<Safety>();
			
		//	if(safety1!=null){
				newSafetyList.add(safety1);
		//	}
			
		try{	
			for(Safety safety:safetyList)
			{
			
			String USER_AGENT = "Mozilla/5.0";
			
			String url = "https://maps.googleapis.com/maps/api/directions/json?origin="+lattitude+","+longitude+"&destination="+safety.getLattitude()+","+safety.getLongitude()+"&key=AIzaSyDwogj3cbT8_snNP6fMQUINud5ZZP9Ii84";

			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);

			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			System.out.println(response.toString());
			
			JSONObject googleResponse = new JSONObject(response.toString());
			
			JSONArray routes= googleResponse.getJSONArray("routes");
			
			JSONObject legs = routes.getJSONObject(0);
			
			JSONArray leg1= legs.getJSONArray("legs");
			
			JSONObject leg2 = leg1.getJSONObject(0);
			
			JSONObject leg3 = leg2.getJSONObject("distance");
			
			String dist= leg3.getString("text");
			
			double dist1= Double.parseDouble(dist.replaceAll(" .+$", ""));
			
			if(dist1<=0.5){
				newSafetyList.add(safety);
			}
			
			}
		}catch (Exception e) {
			throw new SafetyException("Could not get review " , e);
		}
			commit();
			
			return newSafetyList;	
					
		} catch (HibernateException e) {
			rollback();
			throw new SafetyException("Could not get review " , e);
		}
	}
	
	

	public Safety addReview(HttpServletRequest request,User u)
			throws SafetyException {
		try {
			begin();
			System.out.println("inside DAO");

		//	Address address = new Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
		//	Set<Role> roles = u.getRoles();

			Safety safety = new Safety();
			
			safety.setRating(Integer.parseInt(request.getParameter("rating")));
			safety.setComment(request.getParameter("comment"));
			safety.setLattitude(Float.parseFloat(request.getParameter("lattitude")));
			safety.setLongitude(Float.parseFloat(request.getParameter("longitude")));
			safety.setUserId((int)u.getId());
			safety.setMedia(null);
			safety.setPhoto(null);


		//	address.setUser(user);
			

			getSession().save(safety);
			commit();
			return safety;

		} catch (HibernateException e) {
			rollback();
			throw new SafetyException("Exception while creating review: " + e.getMessage());
		}
	}

	public void delete(Safety safety) throws SafetyException {
		try {
			begin();
			getSession().delete(safety);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new SafetyException("Could not delete review " , e);
		}
	}
}