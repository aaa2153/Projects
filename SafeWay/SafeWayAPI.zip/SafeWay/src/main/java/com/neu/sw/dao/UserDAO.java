package com.neu.sw.dao;



import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.HibernateException;
import org.hibernate.Query;


import com.neu.sw.exception.UserException;

import com.neu.sw.pojo.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


public class UserDAO extends DAO {

	public UserDAO() {
	}

	public User get(String email, String password) throws UserException {
		try {
			begin();
			Query q = getSession().createQuery("from User where email = :email");
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
		//	String hashedPassword = passwordEncoder.encode(password);
			q.setString("email", email);
		//	q.setString("password", password);			
			User user = (User) q.uniqueResult();
			commit();
			if(user!=null)
			{
			if(passwordEncoder.matches(password, user.getPassword()))
			{
			return user;
			}
			}
			return null;			
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not get user " + email, e);
		}
	}
	
	

	public User register(HttpServletRequest request)
			throws UserException {
		try {
			begin();
			System.out.println("inside DAO");

		//	Address address = new Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
		//	Set<Role> roles = u.getRoles();

			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String hashedPassword = passwordEncoder.encode(request.getParameter("password"));
			
			User user = new User(request.getParameter("email"), hashedPassword);

			user.setFirstname(request.getParameter("firstname"));
			user.setLastname(request.getParameter("lastname"));
			user.setMobileNumber(request.getParameter("mobileNumber"));

		//	address.setUser(user);
			

			getSession().save(user);
			commit();
			return user;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}

	public void delete(User user) throws UserException {
		try {
			begin();
			getSession().delete(user);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not delete user " + user.getEmail(), e);
		}
	}
}