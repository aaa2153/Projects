package com.neu.sw.exception;



public class SafetyException extends Exception {

	public SafetyException(String message)
	{
		super("SafetyException-"+message);
	}
	
	public SafetyException(String message, Throwable cause)
	{
		super("SafetyException-"+message,cause);
	}
	
}

