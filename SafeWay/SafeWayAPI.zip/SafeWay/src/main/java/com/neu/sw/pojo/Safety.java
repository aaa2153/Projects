package com.neu.sw.pojo;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.Transient;

import org.springframework.web.multipart.commons.CommonsMultipartFile;






@Entity
@Table(name = "Safety")
public class Safety {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Id", unique = true, nullable = false)
	private long id;
	
	@Column(name = "Rating")
	private int rating;
	
	@Column(name = "Comment")
	private String comment;
	
	@Transient
	private CommonsMultipartFile photo;  
	
	@Column(name = "Media")
	private String media;

	@Column(name = "Lattitude")
	private float lattitude;
	
	@Column(name = "Longitude")
	private float longitude;

	@Column(name = "UserId")
	private int userId;
	

	public Safety() {
	
	}


	public long getId() {
		return id;
	}

	

	public CommonsMultipartFile getPhoto() {
		return photo;
	}


	public void setPhoto(CommonsMultipartFile photo) {
		this.photo = photo;
	}



	public int getRating() {
		return rating;
	}


	public void setRating(int rating) {
		this.rating = rating;
	}


	public String getComment() {
		return comment;
	}


	public void setComment(String comment) {
		this.comment = comment;
	}


	public String getMedia() {
		return media;
	}


	public void setMedia(String media) {
		this.media = media;
	}


	public float getLattitude() {
		return lattitude;
	}


	public void setLattitude(float lattitude) {
		this.lattitude = lattitude;
	}


	public float getLongitude() {
		return longitude;
	}


	public void setLongitude(float longitude) {
		this.longitude = longitude;
	}


	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}





	
	
}
