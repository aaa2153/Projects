package com.neu.sw.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.neu.sw.dao.UserDAO;
import com.neu.sw.exception.UserException;
import com.neu.sw.pojo.User;
//import com.neu.hmf.validator.UserValidator;

@Controller
@RequestMapping("/account/*")
public class UserController {

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

//	@Autowired
//	@Qualifier("userValidator")
//	UserValidator validator;

//	@InitBinder
//	private void initBinder(WebDataBinder binder) {
//		binder.setValidator(validator);
//	}
	
	@RequestMapping(value = "/account/login", method = RequestMethod.GET)
	protected String goToUserHome(HttpServletRequest request) throws Exception {
		return "login";
	}
	
	@RequestMapping(value = "/account/logout", method = RequestMethod.GET)
	protected String logout(HttpServletRequest request) throws Exception {
		HttpSession session = (HttpSession) request.getSession();
		session.invalidate();
		return "index";
	}
	
	
	@RequestMapping(value = "/account/login", method = RequestMethod.POST, produces = "application/json")
	protected @ResponseBody String loginUser(HttpServletRequest request,HttpServletResponse response) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		boolean loggedIn=true;
		
		try {

			System.out.print("loginUser");

			User u = userDao.get(request.getParameter("email"), request.getParameter("password"));
			
			if(u == null){
				loggedIn=false;
				System.out.println("UserName/Password does not exist");
				session.setAttribute("errorMessage", "UserName/Password does not exist");
				return "redirect:/";
			}
			
			Gson gson = new Gson();

			String jsonInString = gson.toJson(u);
			
			session.setAttribute("loggedIn", loggedIn);
			session.setAttribute("user", u);
			
			System.out.println(jsonInString);
			return jsonInString;
			
		} catch (UserException e) {
			System.out.println("Exception: " + e.getMessage());
			session.setAttribute("errorMessage", "error while login");
			return "redirect:/";
		}
		
		

	}
	
	@RequestMapping(value = "/account/register", method = RequestMethod.GET)
	protected ModelAndView registerUser() throws Exception {
		System.out.print("registerUser");

		return new ModelAndView("register", "user", new User());

	}
	
	@RequestMapping(value = "/account/register", method = RequestMethod.POST)
	protected ModelAndView registerNewUser(HttpServletRequest request,  @ModelAttribute("user") User user, BindingResult result) throws Exception {

		HttpSession session=request.getSession();
		boolean success=false;
	//	validator.validate(user, result);

//		if (result.hasErrors()) {
//			return new ModelAndView("error", "user", user);
//		}

		try {

			System.out.print("registerNewUser");

			User u = userDao.register(request);
			
			request.getSession().setAttribute("user", u);
			
			success=true;
			session.setAttribute("success", success);
			return new ModelAndView("redirect:/");

		} catch (UserException e) {
			System.out.println("Exception: " + e.getMessage());
			return new ModelAndView("redirect:/", "errorMessage", "error while login");
		}
	}

}
