
$(document).ready(function(e) {

	$("button#pickup").click(function() {

		// alert($(this).children().val());

		$.ajax({
			// url: "http://localhost:8080/hmf/delivery/pickup",
			url : $("input[name=contextPath]").val() + "/delivery/pickup",
			type : "post", // send it through get method
			data : {
				orderId : $(this).children().val()
			},
			dataType : "json",
			success : function(response) {

				$('td.status' + response.id).text(response.status);
				$(this).off('click');

			},
			error : function(xhr) {
				alert("error");
			}
		});

	});

	$("button#drop").click(function() {

		// alert($(this).children().val());

		$.ajax({
			// url: "http://localhost:8080/hmf/delivery/drop",
			url : $("input[name=contextPath]").val() + "/delivery/drop",
			type : "post", // send it through get method
			data : {
				orderId : $(this).children().val()
			},
			dataType : "json",
			success : function(response) {

				$('td.status' + response.id).text(response.status);
				$(this).off('click');

			},
			error : function(xhr) {
				alert("error");
			}
		});

	});

	// var spinner = $("#spinner").spinner();
	$(".rating input:radio").attr("checked", false);
	$('.rating input').click(function() {
		$(".rating span").removeClass('checked');
		$(this).parent().addClass('checked');
	});

	$('input:radio').change(function() {
		var userRating = this.value;
		alert(userRating);
	});

	// e.preventDefault();

	$("div#menudiv").hide();
	$("div.well").hide();
	$("div#addToCart").hide();

	$('a#description').on('click', function(e) {

		e.preventDefault();

		$("div#description").show();
		$("div.well").removeClass("active");
		$("div#menudiv").removeClass("active");
		$("div#description").addClass("active");
		$("div#menudiv").hide();
		$("div.well").hide();
		$('div#addToCart').hide();

	});

	$('a#menu').on('click', function(e) {

		// e.preventDefault();

		$("div#description").hide();
		$("div#menudiv").show();
		$("div#description").removeClass("active");
		$("div.well").removeClass("active");
		$("div#menudiv").addClass("active");
		$("div.well").hide();
		$('div#addToCart').hide();

	});

	$('a#reviews').on('click', function(e) {

		// e.preventDefault();

		$("div#description").hide();
		$("div#menudiv").hide();
		$("div.well").show();
		$("div#menudiv").removeClass("active");
		$("div#description").removeClass("active");
		$("div.well").addClass("active");
		$('div#addToCart').hide();

	});

	$('a#menuClick').on('click', function(e) {

		// e.preventDefault();

		$("div#menudiv").removeClass("active");
		$("div#description").removeClass("active");
		$("div.well").removeClass("active");
		$("div#addToCart").show();
		$('a#menuClick').hide();

	});
});
