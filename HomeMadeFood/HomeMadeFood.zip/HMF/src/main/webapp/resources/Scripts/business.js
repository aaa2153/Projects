$(document).ready(function(e) {

					var count = 0;
					var order = [];
					var userRating;

					$("#cart_table").on(
							'click',
							'a',
							function() {

								order.splice($(this).closest("tr").index(), 1);
								// alert('removed:
								// '+$(this).closest('tr').index());

								$(this).closest("tr").remove();

								$("span.badge").text(
										parseInt($("span.badge").text()) - 1);

							});

					$("#cart_table")
							.on(
									'change',
									'input[value]',
									function() {

										order[$(this).closest("tr").index()].quantity = $(
												this).val();
										order[$(this).closest("tr").index()].subTotal = order[$(
												this).closest("tr").index()].price
												* order[$(this).closest("tr")
														.index()].quantity;

									});

					$("a#checkout")
							.click(
									function() {

										if (order.length != 0) {

											$("div#cart").hide();
											$("div#payment").show();

											$
													.ajax({
														// url:
														// "http://localhost:8080/hmf/customer/checkout",
														url : $(
																"input[name=contextPath]")
																.val()
																+ "/customer/checkout",
														type : "post", // send
																		// it
																		// through
																		// get
																		// method
														data : JSON
																.stringify(order),
														contentType : "application/json; charset=utf-8",
														dataType : "json",
														success : function(
																response) {

														},
														error : function(xhr) {
															// alert("error");
														}
													});

										}

										else {
											alert("Your cart is empty !!!");
										}

									});

					$("span#addToCart")
							.click(
									function() {
										++count;
										$
												.ajax({
													// url:
													// "http://localhost:8080/hmf/customer/cart",
													url : $(
															"input[name=contextPath]")
															.val()
															+ "/customer/cart",
													type : "post", // send it
																	// through
																	// get
																	// method
													data : {
														itemId : $(this)
																.children()
																.val()
													},
													dataType : "json",
													success : function(response) {

														var trHTML = '';
														// $.each(response,
														// function (key,value)
														// {

														// alert(order.response.itemName);

														// if(order.response.itemName!=response.itemName)
														// {

														if (order.length == 0) {
															trHTML += '<tr><td>'
																	+ count
																	+ '</td><td>'
																	+ response.itemName
																	+ '</td><td>'
																	+ '<input type="number" name="qty" min=1  value=1 />'
																	+ '</td><td>'
																	+ response.price
																	+ '</td><td>'
																	+ response.price
																	+ '</td><td>'
																	+ '<a class="btn btn-warning">Remove</a>'
																	+ '</td></tr>';

															// alert('first');

															$('#cart_table')
																	.append(
																			trHTML);

															var orderItems = {
																"index" : count - 1,
																"menuItem" : response.id,
																"itemName" : response.itemName,
																"quantity" : 1,
																"price" : response.price,
																"subTotal" : response.price
															};
															order
																	.push(orderItems);

															$("span.badge")
																	.text('1');
														}

														else {
															var orderItems;

															for (var i = 0; i < order.length; i++) {
																// trHTML = ''

																if (order[i].itemName == response.itemName) {

																	order[i].quantity++;

																	order[i].subTotal = order[i].price
																			* order[i].quantity;

																	// alert('exists');

																}

																else {

																	$(
																			"span.badge")
																			.text(
																					parseInt($(
																							"span.badge")
																							.text()) + 1);

																	trHTML += '<tr><td>'
																			+ count
																			+ '</td><td>'
																			+ response.itemName
																			+ '</td><td>'
																			+ '<input type="number" name="qty" min=1  value=1 />'
																			+ '</td><td>'
																			+ response.price
																			+ '</td><td>'
																			+ parseInt(
																					$(
																							"input[name=qty]")
																							.val(),
																					10)
																			* response.price
																			+ '</td><td>'
																			+ '<a class="btn btn-warning">Remove</a>'
																			+ '</td></tr>';

																	// alert('not
																	// exists');

																	orderItems = {
																		"index" : count - 1,
																		"menuItem" : response.id,
																		"itemName" : response.itemName,
																		"quantity" : parseInt(
																				$(
																						"input[name=qty]")
																						.val(),
																				10),
																		"price" : response.price,
																		"subTotal" : parseInt(
																				$(
																						"input[name=qty]")
																						.val(),
																				10)
																				* response.price
																	};

																	$(
																			'#cart_table')
																			.append(
																					trHTML);
																}

															}
															order
																	.push(orderItems);
														}

														// trHTML +=
														// '<tr><td>' + count +
														// '</td><td>' +
														// response.itemName +
														// '</td><td>' + '<input
														// type="number"
														// name="qty" min=1
														// value=1 />' +
														// '</td><td>' +
														// response.price +
														// '</td><td>' +
														// parseInt($("input[name=qty]").val(),10)*response.price
														// +
														// '</td><td>' + '<a
														// class="btn
														// btn-warning">Remove</a>'
														// +
														// '</td></tr>';

														// alert('next');

														// alert(orderItems.subTotal);
														// }

														// else{
														// $("input[name=qty]").val()=
														// parseInt($("input[name=qty]").val(),10)+1
														// }
														// });

														// alert(response.itemName);

													},
													error : function(xhr) {
														// alert("error");
													}
												});

									});

					$("a#postComment").click(
							function() {
								++count;
								$.ajax({
									// url:
									// "http://localhost:8080/hmf/customer/review",
									url : $("input[name=contextPath]").val()
											+ "/customer/review",
									type : "post", // send it through get
													// method
									data : {
										rating : userRating,
										comment : $("#comment").val()
									},
									dataType : "json",
									success : function(response) {

										alert('Review posted successfully');

									},
									error : function(xhr) {
										// alert("error");
									}
								});

							});

					// var spinner = $("#spinner").spinner();
					// $(".rating input:radio").attr("checked", false);
					// $('.rating input').click(function () {
					// $(".rating span").removeClass('checked');
					// $(this).parent().addClass('checked');
					// });

					$('input:radio').change(function() {
						userRating = this.value;
						alert(userRating);
					});

					// e.preventDefault();

					$("div#menudiv").hide();
					$("div#review").hide();
					$("div#addToCart").hide();
					$("div#cart").hide();
					$("div#payment").hide();

					$('a#description').on('click', function(e) {

						// e.preventDefault();

						$("div#description").show();
						$("div#review").removeClass("active");
						$("div#menudiv").removeClass("active");
						$("div#cart").removeClass("active");
						$("div#description").addClass("active");
						$("div#menudiv").hide();
						$("div#review").hide();
						$('div#addToCart').hide();
						$("div#cart").hide();
						$("div#payment").hide();

					});

					$('a#menu').on('click', function(e) {

						// e.preventDefault();

						$("div#menudiv").show();
						$("div#description").hide();
						$("div#cart").removeClass("active");
						$("div#description").removeClass("active");
						$("div#review").removeClass("active");
						$("div#menudiv").addClass("active");
						$("div#review").hide();
						$('div#addToCart').hide();
						$("div#cart").hide();
						$("div#payment").hide();

					});

					$('a#reviews').on('click', function(e) {

						// e.preventDefault();

						$("div#description").hide();
						$("div#menudiv").hide();
						$("div#review").show();
						$("div#cart").removeClass("active");
						$("div#menudiv").removeClass("active");
						$("div#description").removeClass("active");
						$("div#review").addClass("active");
						$('div#addToCart').hide();
						$("div#cart").hide();
						$("div#payment").hide();

					});

					$('a#cart').on('click', function(e) {

						// e.preventDefault();

						$("div#cart").show();
						$("div#description").hide();
						$("div#menudiv").hide();
						$("div#review").hide();
						$("div#menudiv").removeClass("active");
						$("div#description").removeClass("active");
						$("div#review").removeClass("active");
						$("div#cart").addClass("active");
						$('div#addToCart').hide();
						$("div#payment").hide();

					});

					$('a#menuClick').on('click', function(e) {

						// e.preventDefault();
						$("div#orders").removeClass("active");
						$("div#menudiv").removeClass("active");
						$("div#description").removeClass("active");
						$("div#review").removeClass("active");
						$("div#addToCart").show();
						$('a#menuClick').hide();
						$("div#orders").hide();
						$("div#payment").hide();

					});
				});
