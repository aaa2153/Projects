
$(document).ready(
		function(e) {

			$("#closed").on(
					'click',
					'a',
					function() {

						alert('You can order from here between '
								+ $(this).children('.ot').val() + ' and '
								+ $(this).children('.ct').val());

					});
		});
