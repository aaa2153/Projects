
$(document).ready(
		function(e) {

			$(".dropDownTextArea").css("display", "none");

			$(".spandRows").on("click", function() {
				$(this).parent().parent().next(".dropDownTextArea").toggle();
			});

			$("span#ready").click(
					function() {

						$.ajax({
							// url:
							// "http://localhost:8080/hmf/business/dispatchOrder",
							url : $("input[name=contextPath]").val()
									+ "/business/dispatchOrder",
							type : "post", // send it through get method
							data : {
								orderId : $(this).children().val()
							},
							dataType : "json",
							success : function(response) {

								alert(response.status);

							},
							error : function(xhr) {
								// alert("error");
							}
						});

					});

			$("div#viewMenu").on(
					'click',
					'span',
					function() {

						$.ajax({
							// url:
							// "http://localhost:8080/hmf/business/menu/remove",
							url : $("input[name=contextPath]").val()
									+ "/business/menu/remove",
							type : "post", // send it through get method
							data : {
								itemId : $(this).children().val()
							},
							success : function(response) {

								$('#remove' + response.id).remove();
								// alert("success");

							},
							error : function(xhr) {
								// alert("error");
							}
						});

					});

			// var spinner = $("#spinner").spinner();
			$(".rating input:radio").attr("checked", false);
			$('.rating input').click(function() {
				$(".rating span").removeClass('checked');
				$(this).parent().addClass('checked');
			});

			$('input:radio').change(function() {
				var userRating = this.value;
				alert(userRating);
			});

			// e.preventDefault();

			$("div#menudiv").hide();
			$("div.well").hide();
			$("div#addToCart").hide();
			$("div#orders").hide();

			$('a#description').on('click', function(e) {

				// e.preventDefault();

				$("div#description").show();
				$("div.well").removeClass("active");
				$("div#menudiv").removeClass("active");
				$("div#orders").removeClass("active");
				$("div#description").addClass("active");
				$("div#menudiv").hide();
				$("div.well").hide();
				$('div#addToCart').hide();
				$("div#orders").hide();

			});

			$('a#menu').on('click', function(e) {

				// e.preventDefault();

				$("div#menudiv").show();
				$("div#description").hide();
				$("div#orders").removeClass("active");
				$("div#description").removeClass("active");
				$("div.well").removeClass("active");
				$("div#menudiv").addClass("active");
				$("div.well").hide();
				$('div#addToCart').hide();
				$("div#orders").hide();

			});

			$('a#reviews').on('click', function(e) {

				// e.preventDefault();

				$("div#description").hide();
				$("div#menudiv").hide();
				$("div.well").show();
				$("div#orders").removeClass("active");
				$("div#menudiv").removeClass("active");
				$("div#description").removeClass("active");
				$("div.well").addClass("active");
				$('div#addToCart').hide();
				$("div#orders").hide();

			});

			$('a#order').on('click', function(e) {

				// e.preventDefault();

				$("div#orders").show();
				$("div#description").hide();
				$("div#menudiv").hide();
				$("div.well").hide();
				$("div#menudiv").removeClass("active");
				$("div#description").removeClass("active");
				$("div.well").removeClass("active");
				$("div#orders").addClass("active");
				$('div#addToCart').hide();

			});

			$('a#menuClick').on('click', function(e) {

				// e.preventDefault();
				$("div#orders").removeClass("active");
				$("div#menudiv").removeClass("active");
				$("div#description").removeClass("active");
				$("div.well").removeClass("active");
				$("div#addToCart").show();
				$('a#menuClick').hide();
				$("div#orders").hide();

			});
		});
