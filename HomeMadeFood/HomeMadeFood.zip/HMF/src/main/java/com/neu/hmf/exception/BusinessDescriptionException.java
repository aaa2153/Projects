package com.neu.hmf.exception;

public class BusinessDescriptionException extends Exception {

	public BusinessDescriptionException(String message)
	{
		super("BusinessDescriptionException-"+message);
	}
	
	public BusinessDescriptionException(String message, Throwable cause)
	{
		super("BusinessDescriptionException-"+message,cause);
	}
	
}
