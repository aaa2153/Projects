package com.neu.hmf.dao;

import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.neu.hmf.exception.UserException;
import com.neu.hmf.pojo.Role;
import com.neu.hmf.pojo.User;
import org.hibernate.criterion.Restrictions;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class UserDAO extends DAO {

	public UserDAO() {
	}

	public List<User> getList() throws UserException {
		try {
			begin();
			Query q = getSession().createQuery("from User");

			List<User> userList = q.list();
			commit();

			return userList;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not get user list ", e);
		}
	}

	public User get(String email, String password) throws UserException {
		try {
			begin();
			Query q = getSession().createQuery("from User where email = :email");
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			// String hashedPassword = passwordEncoder.encode(password);
			q.setString("email", email);
			// q.setString("password", password);
			User user = (User) q.uniqueResult();
			commit();
			if (user != null) {
				if (passwordEncoder.matches(password, user.getPassword())) {
					return user;
				}
			}
			return null;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not get user " + email, e);
		}
	}

	public User get(int userId) throws UserException {
		try {
			begin();
			Query q = getSession().createQuery("from User where id = :userId");
			q.setInteger("userId", userId);
			// q.setString("password", password);
			User user = (User) q.uniqueResult();
			commit();
			if (user != null) {

				return user;

			}
			return null;
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not get user " + userId, e);
		}
	}

	public User getDriver(String businessAddress) throws UserException {
		try {
			begin();
			// Query q = getSession().createQuery("from User u inner join Role r
			// on r.userId=u.id where r.delivery = 1");

			Criteria crit = getSession().createCriteria(User.class);

			crit.createAlias("role", "r");

			crit.add(Restrictions.eq("r.delivery", 1));

			// Query q= getSession().createSQLQuery("select * from Users u inner
			// join Roles r on r.UId=u.AddressId where r.Delivery =
			// 1").addEntity(User.class);
			// inner join Role r on r.id=u.role.id where r.delivery = 1
			// q.setInteger("userId", userId);
			// q.setString("password", password);

			// User user=(User)q.uniqueResult();

			List<User> userList = crit.list();

			System.out.println(userList.get(0).getFirstname());

			commit();

			List<Double> distanceList = new ArrayList<Double>();

			for (User user : userList) {

				String driverLocation = user.getStreet1().replaceAll(" ", "+") + "+" + user.getCity() + ",+"
						+ user.getState();

				String USER_AGENT = "Mozilla/5.0";

				String url = "https://maps.googleapis.com/maps/api/directions/json?origin=" + driverLocation
						+ "&destination=" + businessAddress + "&key=AIzaSyDwogj3cbT8_snNP6fMQUINud5ZZP9Ii84";

				URL obj = new URL(url);
				HttpURLConnection con = (HttpURLConnection) obj.openConnection();

				// optional default is GET
				con.setRequestMethod("GET");

				// add request header
				con.setRequestProperty("User-Agent", USER_AGENT);

				int responseCode = con.getResponseCode();
				System.out.println("\nSending 'GET' request to URL : " + url);
				System.out.println("Response Code : " + responseCode);

				BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine;
				StringBuffer response = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
				in.close();

				// print result
				System.out.println(response.toString());

				JSONObject googleResponse = new JSONObject(response.toString());

				JSONArray routes = googleResponse.getJSONArray("routes");

				JSONObject legs = routes.getJSONObject(0);

				JSONArray leg1 = legs.getJSONArray("legs");

				JSONObject leg2 = leg1.getJSONObject(0);

				JSONObject leg3 = leg2.getJSONObject("distance");

				String dist = leg3.getString("text");

				double dist1 = Double.parseDouble(dist.replaceAll(" .+$", ""));

				distanceList.add(dist1);

			}

			double minVal = distanceList.get(0); // Keeps a running count of the
													// smallest value so far
			int minIdx = 0; // Will store the index of minVal
			for (int i = 1; i < distanceList.size(); i++) {
				if (distanceList.get(i) < minVal) {
					minVal = distanceList.get(i);
					minIdx = i;
				}
			}

			System.out.println("min index :" + minIdx);

			User u = userList.get(minIdx);

			System.out.println("name :" + u.getFirstname());

			// String jsonInString = gson.fromJson(json, typeOfT)

			// System.out.println(jsonInString);
			// return jsonInString;

			return u;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not get user ", e);
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			throw new UserException("Could not get user ", e);
		}
	}

	public User register(User u) throws UserException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();
			Role role = new Role(1, 0, 0);
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			String hashedPassword = passwordEncoder.encode(u.getPassword());

			User user = new User(u.getEmail(), hashedPassword);

			user.setFirstname(u.getFirstname());
			user.setLastname(u.getLastname());
			user.setDob(u.getDob());
			user.setStreet1(u.getStreet1());
			user.setStreet2(u.getStreet2());
			user.setCity(u.getCity());
			user.setState(u.getState());
			user.setCountry(u.getCountry());
			user.setZip(u.getZip());
			user.setMobile(u.getMobile());
			user.setRole(role);
			role.setUser(user);
			role.setUserId(user.getId());
			// address.setUser(user);

			getSession().save(user);
			commit();
			return user;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}

	public User updateBusiness(User user) throws UserException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();
			Role role = user.getRole();

			role.setBusiness(1);

			user.setRole(role);
			role.setUser(user);
			// address.setUser(user);

			getSession().update(user);
			commit();
			return user;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}

	public User updateDelivery(User user) throws UserException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();
			Role role = user.getRole();

			role.setDelivery(1);

			user.setRole(role);
			role.setUser(user);
			// address.setUser(user);

			getSession().update(user);
			commit();
			return user;

		} catch (HibernateException e) {
			rollback();
			throw new UserException("Exception while creating user: " + e.getMessage());
		}
	}

	public void delete(User user) throws UserException {
		try {
			begin();
			getSession().delete(user);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new UserException("Could not delete user " + user.getEmail(), e);
		}
	}
}