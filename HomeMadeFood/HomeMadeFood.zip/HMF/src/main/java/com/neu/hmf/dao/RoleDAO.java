package com.neu.hmf.dao;

import org.hibernate.HibernateException;
import com.neu.hmf.dao.DAO;
import com.neu.hmf.exception.RoleException;
import com.neu.hmf.pojo.Role;

public class RoleDAO extends DAO {

	public Role create(Role role) throws RoleException {
		try {
			begin();
			getSession().save(role);
			commit();
			return role;
		} catch (HibernateException e) {
			rollback();
			// throw new AdException("Could not create Role", e);
			throw new RoleException("Exception while creating Role: " + e.getMessage());
		}
	}

	public void delete(Role role) throws RoleException {
		try {
			begin();
			getSession().delete(role);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new RoleException("Could not delete Role", e);
		}
	}

	// public List<Role> list() throws RoleException{
	//
	// try {
	// begin();
	// Query q = getSession().createQuery("from Role");
	// List<Role> Roles = q.list();
	// commit();
	// return Roles;
	// } catch (HibernateException e) {
	// rollback();
	// throw new RoleException("Could not delete Role", e);
	// }
	//
	// }
}