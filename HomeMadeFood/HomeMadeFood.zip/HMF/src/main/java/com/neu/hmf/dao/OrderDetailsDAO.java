package com.neu.hmf.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.OrderDetailsException;
import com.neu.hmf.pojo.OrderDetails;

public class OrderDetailsDAO extends DAO {

	public OrderDetailsDAO() {
	}

	public List<OrderDetails> getOrderDetails(long orderId) throws OrderDetailsException {
		try {
			begin();
			Query q = getSession().createQuery("from OrderDetails where orderId = :orderId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("orderId", orderId);
			// q.setString("password", password);
			List<OrderDetails> orderDetailsList = q.list();
			commit();

			for (OrderDetails od : orderDetailsList) {

				Query q1 = getSession().createQuery(
						"select m.itemName from Menu m INNER JOIN OrderDetails o ON o.menuItem=m.id where o.id= :orderDetailsId");

				q1.setLong("orderDetailsId", od.getId());

				od.setItemName((String) q1.uniqueResult());

			}

			// List<Menu> menuList = q1.list();
			//
			// for(Menu menu:menuList){
			//
			//
			// if(menu!=null)
			// {
			// System.out.println(itemName);

			// orderDetails.setItemName(itemName);
			// }
			// }
			return orderDetailsList;

		} catch (HibernateException e) {
			rollback();
			throw new OrderDetailsException("Could not get Item", e);
		}
	}

	public OrderDetails saveOrderDetails(int menuItem, float price, int qty, float total, int orderId)
			throws OrderDetailsException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			OrderDetails orderDetails = new OrderDetails(menuItem, price, qty, total, orderId);

			// u.setBusinessDescription(businessDescription);

			getSession().save(orderDetails);
			commit();
			return orderDetails;

		} catch (HibernateException e) {
			rollback();
			throw new OrderDetailsException("Exception while placing OrderDetails: " + e.getMessage());
		}
	}

	public void delete(OrderDetails orderDetails) throws OrderDetailsException {
		try {
			begin();
			getSession().delete(orderDetails);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new OrderDetailsException("Could not delete OrderDetails " + orderDetails.getId(), e);
		}
	}
}