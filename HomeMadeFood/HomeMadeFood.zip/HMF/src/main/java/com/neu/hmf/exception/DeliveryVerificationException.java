package com.neu.hmf.exception;

public class DeliveryVerificationException extends Exception {

	public DeliveryVerificationException(String message)
	{
		super("DeliveryException-"+message);
	}
	
	public DeliveryVerificationException(String message, Throwable cause)
	{
		super("DeliveryException-"+message,cause);
	}
	
}
