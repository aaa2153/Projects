package com.neu.hmf.controller;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.neu.hmf.dao.BusinessDescriptionDAO;
import com.neu.hmf.dao.DeliveryVerificationDAO;
import com.neu.hmf.dao.FoodHandlerPermitDAO;
import com.neu.hmf.dao.MenuDAO;
import com.neu.hmf.dao.UserDAO;
import com.neu.hmf.exception.DeliveryVerificationException;
import com.neu.hmf.exception.FoodHandlerPermitException;
import com.neu.hmf.pojo.DeliveryVerification;
import com.neu.hmf.pojo.FoodHandlerPermit;
import com.neu.hmf.pojo.User;

@Controller
@RequestMapping("/manage/*")
public class AccountController {

	@Autowired
	@Qualifier("foodHandlerPermitDao")
	FoodHandlerPermitDAO foodHandlerPermitDao;

	@Autowired
	@Qualifier("deliveryVerificationDao")
	DeliveryVerificationDAO deliveryVerificationDao;

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

	@Autowired
	@Qualifier("bdDao")
	BusinessDescriptionDAO bdDao;

	@Autowired
	@Qualifier("menuDao")
	MenuDAO menuDao;

	@Autowired
	ServletContext servletContext;

	@RequestMapping(value = "/business/verify", method = RequestMethod.POST)
	protected String verifyBusiness(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		boolean businessVerified = true;

		try {

			System.out.print("loginUser");

			FoodHandlerPermit fhp = foodHandlerPermitDao.get(request.getParameter("email"),
					request.getParameter("password"));

			if (fhp == null) {
				businessVerified = false;
				System.out.println("UserName/Password does not exist");
				session.setAttribute("errorMessage", "UserName/Password does not exist");
				return "redirect:/account/error";
			}

			session.setAttribute("businessVerified", businessVerified);
			session.setAttribute("fhp", fhp);

			User user = (User) session.getAttribute("user");

			userDao.updateBusiness(user);

			return "redirect:/account/";

		} catch (FoodHandlerPermitException e) {
			System.out.println("Exception: " + e.getMessage());
			session.setAttribute("errorMessage", "error while login");
			return "redirect:/account/error";
		}
	}

	@RequestMapping(value = "/delivery/verify", method = RequestMethod.POST)
	protected String verifyDelivery(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		boolean businessVerified = true;

		try {

			System.out.print("loginUser");

			DeliveryVerification d = deliveryVerificationDao.get(request.getParameter("email"),
					request.getParameter("password"));

			if (d == null) {
				// businessVerified=false;
				System.out.println("UserName/Password does not exist");
				session.setAttribute("errorMessage", "UserName/Password does not exist");
				return "redirect:/account/error";
			}

			session.setAttribute("businessVerified", businessVerified);
			// session.setAttribute("fhp", fhp);

			User user = (User) session.getAttribute("user");

			userDao.updateDelivery(user);

			return "redirect:/account/";

		} catch (DeliveryVerificationException e) {
			System.out.println("Exception: " + e.getMessage());
			session.setAttribute("errorMessage", "error while login");
			return "redirect:/account/error";
		}
	}

	

	@RequestMapping(value = "/manage/delivery", method = RequestMethod.GET)
	protected String manageDelivery(HttpServletRequest request) throws Exception {

		return "manageDelivery";
	}

	@RequestMapping(value = "/order/error", method = RequestMethod.GET)
	protected String error(HttpServletRequest request) throws Exception {
		return "error";
	}

	@RequestMapping(value = "/order/logout", method = RequestMethod.GET)
	protected String logout(HttpServletRequest request) throws Exception {
		HttpSession session = (HttpSession) request.getSession();
		session.invalidate();
		return "index";
	}

	@RequestMapping(value = "/order/login", method = RequestMethod.POST)
	protected String loginUser(HttpServletRequest request) throws Exception {

		return null;
	}

	@RequestMapping(value = "/order/register", method = RequestMethod.GET)
	protected ModelAndView registerUser() throws Exception {
		System.out.print("registerUser");

		return new ModelAndView("register", "user", new User());

	}

	
}
