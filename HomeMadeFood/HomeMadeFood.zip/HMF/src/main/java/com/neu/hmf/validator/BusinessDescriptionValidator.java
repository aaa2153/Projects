package com.neu.hmf.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.hmf.pojo.BusinessDescription;

public class BusinessDescriptionValidator implements Validator {

	public boolean supports(Class aClass) {
		return aClass.equals(BusinessDescription.class);
	}

	public void validate(Object obj, Errors errors) {
		BusinessDescription businessDescription = (BusinessDescription) obj;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "businessName", "error.invalid.businessDescription",
				"Business Name Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description", "error.invalid.businessDescription",
				"description Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "image", "error.invalid.businessDescription",
				"Image Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "photo", "error.invalid.businessDescription",
				"Image Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "youtubeLink", "error.invalid.businessDescription",
				"Youtube Link Required");

	}
}
