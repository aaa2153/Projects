package com.neu.hmf.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.neu.hmf.dao.BusinessDescriptionDAO;
import com.neu.hmf.dao.MenuDAO;
import com.neu.hmf.dao.OrderDAO;
import com.neu.hmf.dao.OrderDetailsDAO;
import com.neu.hmf.dao.PayPalVerificationDAO;
import com.neu.hmf.dao.ReviewDAO;
import com.neu.hmf.dao.UserDAO;
import com.neu.hmf.exception.MenuException;
import com.neu.hmf.exception.ReviewException;
import com.neu.hmf.pojo.BusinessDescription;
import com.neu.hmf.pojo.Menu;
import com.neu.hmf.pojo.Order;
import com.neu.hmf.pojo.PayPalVerification;
import com.neu.hmf.pojo.Review;
import com.neu.hmf.pojo.User;

@Controller
@RequestMapping("/customer/*")
public class CustomerController {

	@Autowired
	@Qualifier("bdDao")
	BusinessDescriptionDAO bdDao;

	@Autowired
	@Qualifier("menuDao")
	MenuDAO menuDao;

	@Autowired
	@Qualifier("reviewDao")
	ReviewDAO reviewDao;

	@Autowired
	@Qualifier("ppvDao")
	PayPalVerificationDAO ppvDao;

	@Autowired
	@Qualifier("orderDao")
	OrderDAO orderDao;

	@Autowired
	@Qualifier("orderDetailsDao")
	OrderDetailsDAO orderDetailsDao;

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

	@RequestMapping(value = "/customer/{id}", method = RequestMethod.GET)
	protected ModelAndView userorder(HttpServletRequest request, @PathVariable("id") long businessId) throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		// Long businessId= (Long)session.getAttribute("descId");

		BusinessDescription bd = bdDao.getDescription(businessId);

		List<Review> reviewList = reviewDao.getAllReviews(bd.getUserId());

		int rating = 0;

		for (Review review : reviewList) {

			rating += review.getRating();

		}

		if (reviewList.size() != 0) {
			bd.setTotalRating(rating / reviewList.size());
		}

		else {
			bd.setTotalRating(0);
		}

		bd.setReviewCount(reviewList.size());

		List<Menu> menuList = menuDao.getMenu(bd.getUserId());

		User business = userDao.get(bd.getUserId());

		List<Review> allReviews = reviewDao.get(business);

		session.setAttribute("allReviews", allReviews);

		session.setAttribute("menuList", menuList);
		session.setAttribute("description", bd);

		Boolean loggedIn = (Boolean) session.getAttribute("loggedIn");
		if (loggedIn != null) {
			if (loggedIn == true) {
				return new ModelAndView("business", "description", bd);
			}
		}
		return new ModelAndView("redirect:/account/login");
	}

	@RequestMapping(value = "/customer/cart", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	protected String addToCart(@RequestParam("itemId") long itemId, HttpServletRequest request,
			@ModelAttribute("menu") Menu m, BindingResult result) throws Exception {

		try {

			System.out.print("item: " + itemId);

			Menu menu = menuDao.getMenuItem(itemId);

			Gson gson = new Gson();

			String jsonInString = gson.toJson(menu);

			System.out.println(jsonInString);
			return jsonInString;

		} catch (MenuException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/customer/checkout", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	protected String checkout(@RequestBody String cartItems, HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		try {

			Gson gson = new Gson();

			Object[] orderItems = gson.fromJson(cartItems, Object[].class);

			JSONArray jsonArray = new JSONArray(cartItems);

			session.setAttribute("order", jsonArray);
			session.setAttribute("cartItems", cartItems);

			// System.out.print(orderItems[1]);

			// Menu menu = menuDao.getMenuItem(itemId);

			// String jsonInString = gson.toJson();

			System.out.println("success");
			System.out.println(jsonArray);
			return cartItems;

		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/customer/placeOrder", method = RequestMethod.POST)
	protected String placeOrder(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		boolean orderPlaced = false;

		try {

			PayPalVerification ppv = ppvDao.get(request.getParameter("email"), request.getParameter("password"));

			if (ppv != null) {

				User customer = (User) session.getAttribute("user");

				BusinessDescription bd = (BusinessDescription) session.getAttribute("description");

				User business = userDao.get(bd.getUserId());

				Order order = orderDao.placeOrder((int) customer.getId(), (int) business.getId(), 0);

				// Object[] orderItems =
				// (Object[])session.getAttribute("order");

				JSONArray orderItems = (JSONArray) session.getAttribute("order");

				float amount = 0;

				// for(Object item:orderItems){
				for (int i = 0; i < orderItems.length(); i++) {

					JSONObject json = orderItems.getJSONObject(i);

					orderDetailsDao.saveOrderDetails(json.getInt("menuItem"), (float) json.getDouble("price"),
							json.getInt("quantity"), (float) json.getDouble("subTotal"), (int) order.getId());

					amount += (float) json.getDouble("subTotal");

				}

				orderDao.updateOrder(order, amount);

				System.out.println("success");

				orderPlaced = true;

				session.setAttribute("orderPlaced", orderPlaced);
				
				return "redirect:/";
			}
			session.setAttribute("orderPlaced", orderPlaced);

			return "error";

		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/customer/review", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	protected String addReview(@RequestParam("rating") int rating, @RequestParam("comment") String comment,
			HttpServletRequest request) throws Exception {

		try {

			System.out.print("review");

			HttpSession session = request.getSession();

			User customer = (User) session.getAttribute("user");

			BusinessDescription bd = (BusinessDescription) session.getAttribute("description");

			User business = userDao.get(bd.getUserId());

			Review review = reviewDao.add(rating, comment, business, customer);

			Gson gson = new Gson();

			String jsonInString = gson.toJson(review);

			System.out.println(jsonInString);
			return jsonInString;

		} catch (ReviewException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

}
