package com.neu.hmf.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.neu.hmf.dao.BusinessDescriptionDAO;
import com.neu.hmf.dao.ReviewDAO;
import com.neu.hmf.dao.TimingDAO;
import com.neu.hmf.dao.UserDAO;
import com.neu.hmf.pojo.BusinessDescription;
import com.neu.hmf.pojo.Review;
import com.neu.hmf.pojo.Timing;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

	@Autowired
	@Qualifier("bdDao")
	BusinessDescriptionDAO bdDao;

	@Autowired
	@Qualifier("timingDao")
	TimingDAO timingDao;

	@Autowired
	@Qualifier("reviewDao")
	ReviewDAO reviewDao;

	/**
	 * Simply selects the home view to render by returning its name.
	 * 
	 * @throws Exception
	 */

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error(HttpServletRequest request, Locale locale, Model model) throws Exception {

		return "error";

	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request, Locale locale, Model model) throws Exception {

		HttpSession session = request.getSession();

		List<BusinessDescription> businessList = bdDao.getList();

		List<Timing> allBusiness = timingDao.get();

		List<BusinessDescription> openBusiness = new ArrayList<BusinessDescription>();

		List<BusinessDescription> closedBusiness = new ArrayList<BusinessDescription>();

		for (Timing timing : allBusiness) {

			BusinessDescription bd = bdDao.getBD(timing.getBusiness());

			List<Review> reviewList = reviewDao.getAllReviews(bd.getUserId());

			int rating = 0;

			for (Review review : reviewList) {

				rating += review.getRating();

			}

			if (reviewList.size() != 0) {

				bd.setTotalRating(rating / reviewList.size());
			}

			else {
				bd.setTotalRating(0);
			}
			bd.setReviewCount(reviewList.size());

			String openingTime = timing.getOpeningTime();
			String closingTime = timing.getClosingTime();

			bd.setOpeningTime(openingTime);
			bd.setClosingTime(closingTime);

			String[] openingTimeComponents = openingTime.split(":");
			String[] closingTimeComponents = closingTime.split(":");

			int openingtimehr = Integer.parseInt(openingTimeComponents[0]);
			int openingtimemin = Integer.parseInt(openingTimeComponents[1]);
			int closingtimehr = Integer.parseInt(closingTimeComponents[0]);
			int closingtimemin = Integer.parseInt(closingTimeComponents[1]);

			SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
			String str = sdf.format(new Date());

			String[] currentTimeComponents = str.split(":");

			int currenttimehr = Integer.parseInt(currentTimeComponents[0]);
			int currenttimemin = Integer.parseInt(currentTimeComponents[1]);

			System.out.println("current hr: " + currenttimehr);
			System.out.println("current min: " + currenttimemin);
			System.out.println("open hr: " + openingtimehr);
			System.out.println("open min: " + openingtimemin);
			System.out.println("closed hr: " + closingtimehr);
			System.out.println("closed min: " + closingtimemin);

			if (currenttimehr >= openingtimehr && currenttimemin >= openingtimemin && currenttimehr < closingtimehr) {

				openBusiness.add(bd);
			}

			else {
				closedBusiness.add(bd);
			}

		}

		session.setAttribute("openBusinessList", openBusiness);
		session.setAttribute("closedBusinessList", closedBusiness);

		return new ModelAndView("index", "businessList", businessList);
	}

}
