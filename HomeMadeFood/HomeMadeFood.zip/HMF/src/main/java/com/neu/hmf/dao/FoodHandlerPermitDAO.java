package com.neu.hmf.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.FoodHandlerPermitException;
import com.neu.hmf.pojo.FoodHandlerPermit;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class FoodHandlerPermitDAO extends DAO {

	public FoodHandlerPermitDAO() {
	}

	public FoodHandlerPermit get(String email, String password) throws FoodHandlerPermitException {
		try {
			begin();
			Query q = getSession().createQuery("from FoodHandlerPermit where email = :email");
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			// String hashedPassword = passwordEncoder.encode(password);
			q.setString("email", email);
			// q.setString("password", password);
			FoodHandlerPermit fhp = (FoodHandlerPermit) q.uniqueResult();
			commit();
			if (fhp != null) {
				if (passwordEncoder.matches(password, fhp.getPassword())) {
					return fhp;
				}
			}
			return null;
		} catch (HibernateException e) {
			rollback();
			throw new FoodHandlerPermitException("Could not get user " + email, e);
		}
	}

}