package com.neu.hmf.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

@Entity
@Table(name = "Users")
@PrimaryKeyJoinColumn(name = "AddressId")
public class User extends Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "UId", unique = true, nullable = false)
	private long id;

	@Pattern(regexp = "[a-zA-Z ]*$", message = "Please enter alphabets only")
	@Column(name = "FirstName")
	private String firstname;

	@Pattern(regexp = "[a-zA-Z ]*$", message = "Please enter alphabets only")
	@Column(name = "LastName")
	private String lastname;

	@NotNull
	@Column(name = "DOB")
	private String dob;

	@Email
	@Column(name = "Email")
	private String email;

	@Pattern(regexp = "([0-9]{10})", message = "Please enter valid Mobile No.")
	@Column(name = "MobileNo")
	private String mobile;

	@Size(min = 3, max = 60, message = "Password length should be between 3 to 8")
	@Column(name = "Password")
	private String password;

	@Transient
	private String cmfpassword;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "RoleId")
	private Role role;

	@Transient
	private long roleId;

	// @OneToOne(mappedBy="user1")
	// private BusinessDescription businessDescription;

	public User(String email, String password) {
		this.email = email;
		this.password = password;
	}

	public User() {

	}

	public long getId() {
		return id;
	}

	// public BusinessDescription getBusinessDescription() {
	// return businessDescription;
	// }
	//
	// public void setBusinessDescription(BusinessDescription
	// businessDescription) {
	// this.businessDescription = businessDescription;
	// }

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = role.getId();
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

}
