package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Roles")
public class Role {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RoleId", unique = true, nullable = false)
	private long id;

	@Column(name = "Customer")
	private int customer;

	@Column(name = "Business")
	private int business;

	@Column(name = "Delivery")
	private int delivery;

	@Column(name = "UId")
	private long userId;

	@OneToOne(mappedBy = "role")
	private User user;

	public Role() {
	}

	public Role(int customer, int business, int delivery) {
		this.customer = customer;
		this.business = business;
		this.delivery = delivery;
	}

	public long getId() {
		return id;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public int getCustomer() {
		return customer;
	}

	public void setCustomer(int customer) {
		this.customer = customer;
	}

	public int getBusiness() {
		return business;
	}

	public void setBusiness(int business) {
		this.business = business;
	}

	public int getDelivery() {
		return delivery;
	}

	public void setDelivery(int delivery) {
		this.delivery = delivery;
	}

}