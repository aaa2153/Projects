package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Timing")
public class Timing {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TimeId", unique = true, nullable = false)
	private long id;

	@Column(name = "BusinessId")
	private int businessId;

	// @Temporal(TemporalType.TIME)
	@Column(name = "OpeningTime")
	private String openingTime;

	// @Temporal(TemporalType.TIME)
	@Column(name = "ClosingTime")
	private String closingTime;

	public Timing() {

	}

	public long getId() {
		return id;
	}

	public int getBusiness() {
		return businessId;
	}

	public void setBusiness(int businessId) {
		this.businessId = businessId;
	}

	public String getOpeningTime() {
		return openingTime;
	}

	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}

	public String getClosingTime() {
		return closingTime;
	}

	public void setClosingTime(String closingTime) {
		this.closingTime = closingTime;
	}

}
