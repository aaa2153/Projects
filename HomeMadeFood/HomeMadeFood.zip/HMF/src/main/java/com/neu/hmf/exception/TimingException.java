package com.neu.hmf.exception;

public class TimingException extends Exception {

	public TimingException(String message)
	{
		super("TimingException-"+message);
	}
	
	public TimingException(String message, Throwable cause)
	{
		super("TimingException-"+message,cause);
	}
	
}
