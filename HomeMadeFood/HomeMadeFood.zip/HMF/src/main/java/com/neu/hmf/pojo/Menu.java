package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Entity
@Table(name = "Menu")
public class Menu {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ItemId", unique = true, nullable = false)
	private long id;

	@Size(max = 50, message = "max limit 50 characters")
	@Column(name = "ItemName")
	private String itemName;

	@Size(max = 180, message = "max limit 180 characters")
	@Column(name = "ItemDescription")
	private String itemDescription;

	@Transient
	private CommonsMultipartFile photo;

	@Column(name = "Image")
	private String image;

	@Digits(integer = 3, fraction = 2, message = "Please enter valid price")
	@Column(name = "Price")
	private float price;

	@Column(name = "UId")
	private int userId;

	public Menu() {

	}

	public long getId() {
		return id;
	}

	public CommonsMultipartFile getPhoto() {
		return photo;
	}

	public void setPhoto(CommonsMultipartFile photo) {
		this.photo = photo;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
