package com.neu.hmf.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.hmf.pojo.Menu;

public class MenuValidator implements Validator {

	public boolean supports(Class aClass) {
		return aClass.equals(Menu.class);
	}

	public void validate(Object obj, Errors errors) {
		Menu menu = (Menu) obj;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemName", "error.invalid.menu", "Item Name Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "itemDescription", "error.invalid.menu",
				"Item description Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "image", "error.invalid.menu", "Image Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "photo", "error.invalid.menu", "Image Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "price", "error.invalid.menu", "Price Required");

	}
}
