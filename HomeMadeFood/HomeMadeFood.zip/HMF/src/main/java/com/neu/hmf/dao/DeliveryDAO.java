package com.neu.hmf.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import com.neu.hmf.exception.DeliveryException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.Delivery;
import com.neu.hmf.pojo.Order;

public class DeliveryDAO extends DAO {

	public DeliveryDAO() {
	}

	public List<Delivery> getDeliveryList(User u) throws DeliveryException {
		try {
			begin();
			Query q = getSession().createQuery(
					"from Delivery d INNER JOIN Order o on o.id = d.orderId where o.status like :status and d.driverId = :driverId");

			// INNER JOIN Order o on o.id=d.orderId where o.status = 'Ready for
			// Delivery' and
			// INNER JOIN Order o on o.id = d.orderId where o.status = :status
			// and

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("driverId", u.getId());
			// q.setLong("orderId", )
			q.setString("status", "Ready for Delivery");
			// q.setString("password", password);
			// Delivery delivery = (Delivery) q.uniqueResult();

			List<Delivery> deliveryList = q.list();

			commit();

			return deliveryList;

		} catch (HibernateException e) {
			rollback();
			throw new DeliveryException("Could not get Item", e);
		}
	}

	public Delivery addOrder(User business, User customer, User driver, Order order) throws DeliveryException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Query q = getSession().createQuery("select a.id from Address a
			// inner join User u on u.id=");

			Delivery delivery = new Delivery(
					business.getStreet1() + ", " + business.getCity() + ", " + business.getState(),
					customer.getStreet1() + ", " + customer.getCity() + ", " + customer.getState(),
					(int) driver.getId(), (int) order.getId(), business.getMobile(), customer.getMobile());

			// u.setBusinessDescription(businessDescription);

			getSession().save(delivery);
			commit();
			return delivery;

		} catch (HibernateException e) {
			rollback();
			throw new DeliveryException("Exception while managing Delivery: " + e.getMessage());
		}
	}

	public Delivery updateDelivery(Delivery delivery, float amount) throws DeliveryException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Delivery delivery = new Delivery();

			// delivery.setAmount(amount);

			// u.setBusinessDescription(businessDescription);

			getSession().update(delivery);
			commit();
			return delivery;

		} catch (HibernateException e) {
			rollback();
			throw new DeliveryException("Exception while updating Delivery: " + e.getMessage());
		}
	}

	public void delete(Delivery delivery) throws DeliveryException {
		try {
			begin();
			getSession().delete(delivery);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new DeliveryException("Could not delete Delivery " + delivery.getId(), e);
		}
	}
}