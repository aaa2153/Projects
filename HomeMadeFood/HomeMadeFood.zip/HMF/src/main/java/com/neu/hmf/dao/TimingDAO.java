package com.neu.hmf.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.TimingException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.Timing;

public class TimingDAO extends DAO {

	public TimingDAO() {
	}

	public Timing getTiming(User u) throws TimingException {
		try {
			begin();
			Query q = getSession().createQuery("from Timing where businessId = :businessId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("businessId", (int) u.getId());
			// q.setString("password", password);
			// Timing timing = (Timing) q.uniqueResult();

			Timing timing = (Timing) q.uniqueResult();

			commit();

			if (timing != null) {
				return timing;
			}

			return null;

		} catch (HibernateException e) {
			rollback();
			throw new TimingException("Could not get Item", e);
		}
	}

	public List<Timing> get() throws TimingException {
		try {
			begin();
			Query q = getSession().createQuery("from Timing");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);

			// q.setString("password", password);
			// Timing timing = (Timing) q.uniqueResult();

			List<Timing> timing = q.list();

			commit();

			if (timing != null) {
				return timing;
			}

			return null;

		} catch (HibernateException e) {
			rollback();
			throw new TimingException("Could not get Time", e);
		}
	}

	public Timing addTiming(Timing t, User u) throws TimingException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			Timing timing = new Timing();

			timing.setBusiness((int) u.getId());
			timing.setOpeningTime(t.getOpeningTime());
			timing.setClosingTime(t.getClosingTime());
			// u.setBusinessDescription(businessDescription);
			// System.out.println(t.getOpeningTime().toString());
			getSession().save(timing);

			commit();
			return timing;

		} catch (HibernateException e) {
			rollback();
			throw new TimingException("Exception while adding Time: " + e.getMessage());
		}
	}

	public Timing updateTiming(Timing t, User u) throws TimingException {
		try {
			// begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			Timing timing = getTiming(u);

			timing.setOpeningTime(t.getOpeningTime());
			timing.setClosingTime(t.getClosingTime());

			// u.setBusinessDescription(businessDescription);
			System.out.println(t.getOpeningTime().toString());
			getSession().update(timing);
			begin();
			commit();
			return timing;

		} catch (HibernateException e) {
			rollback();
			throw new TimingException("Exception while updating Timing: " + e.getMessage());
		}
	}

	public void delete(Timing timing) throws TimingException {
		try {
			begin();
			getSession().delete(timing);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new TimingException("Could not delete Timing " + timing.getId(), e);
		}
	}
}