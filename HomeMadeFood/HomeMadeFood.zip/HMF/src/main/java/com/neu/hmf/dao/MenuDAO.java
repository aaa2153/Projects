package com.neu.hmf.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.MenuException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.Menu;

public class MenuDAO extends DAO {

	public MenuDAO() {
	}

	public List<Menu> get(User u) throws MenuException {
		try {
			begin();
			Query q = getSession().createQuery("from Menu where userId = :userId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("userId", (int) u.getId());
			// q.setString("password", password);
			List<Menu> menu = q.list();
			commit();

			return menu;

		} catch (HibernateException e) {
			rollback();
			throw new MenuException("Could not get Item for " + u.getFirstname(), e);
		}
	}

	public List<Menu> getMenu(int userId) throws MenuException {
		try {
			begin();
			Query q = getSession().createQuery("from Menu where userId = :userId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("userId", userId);
			// q.setString("password", password);
			List<Menu> menu = q.list();
			commit();

			return menu;

		} catch (HibernateException e) {
			rollback();
			throw new MenuException("Could not get Item", e);
		}
	}

	public Menu getMenuItem(long itemId) throws MenuException {
		try {
			begin();
			Query q = getSession().createQuery("from Menu where itemId = :itemId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("itemId", itemId);
			// q.setString("password", password);
			Menu menu = (Menu) q.uniqueResult();
			;
			commit();

			return menu;

		} catch (HibernateException e) {
			rollback();
			throw new MenuException("Could not get Item", e);
		}
	}

	public Menu add(Menu m, User u) throws MenuException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			Menu menu = new Menu();

			menu.setImage(m.getImage());
			menu.setItemDescription(m.getItemDescription());
			menu.setItemName(m.getItemName());
			menu.setPhoto(m.getPhoto());
			menu.setPrice(m.getPrice());
			menu.setUserId((int) u.getId());
			// u.setBusinessDescription(businessDescription);

			getSession().save(menu);
			commit();
			return menu;

		} catch (HibernateException e) {
			rollback();
			throw new MenuException("Exception while creating Menu: " + e.getMessage());
		}
	}

	public void delete(Menu menu) throws MenuException {
		try {
			begin();
			getSession().delete(menu);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new MenuException("Could not delete Menu " + menu.getItemName(), e);
		}
	}
}