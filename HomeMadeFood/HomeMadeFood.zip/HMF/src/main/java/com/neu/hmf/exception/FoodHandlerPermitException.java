package com.neu.hmf.exception;

public class FoodHandlerPermitException extends Exception {

	public FoodHandlerPermitException(String message)
	{
		super("FoodHandlerPermitException-"+message);
	}
	
	public FoodHandlerPermitException(String message, Throwable cause)
	{
		super("FoodHandlerPermitException-"+message,cause);
	}
	
}
