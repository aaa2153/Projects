package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Delivery")
public class Delivery {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DeliveryId", unique = true, nullable = false)
	private long id;

	@Column(name = "PickUpLocation")
	private String pickup;

	@Column(name = "DropOffLocation")
	private String dropoff;

	@Column(name = "PickUpContact")
	private String pickupContact;

	@Column(name = "DropOffContact")
	private String dropoffContact;

	@Column(name = "DriverId")
	private int driverId;

	@Column(name = "OrderId")
	private int orderId;

	public Delivery() {

	}

	public Delivery(String pickup, String dropoff, int driverId, int orderId, String pickupContact,
			String dropoffContact) {

		this.pickup = pickup;
		this.dropoff = dropoff;
		this.driverId = driverId;
		this.orderId = orderId;
		this.pickupContact = pickupContact;
		this.dropoffContact = dropoffContact;
	}

	public long getId() {
		return id;
	}

	public String getPickup() {
		return pickup;
	}

	public void setPickup(String pickup) {
		this.pickup = pickup;
	}

	public String getDropoff() {
		return dropoff;
	}

	public void setDropoff(String dropoff) {
		this.dropoff = dropoff;
	}

	public int getDriverId() {
		return driverId;
	}

	public void setDriverId(int driverId) {
		this.driverId = driverId;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getPickupContact() {
		return pickupContact;
	}

	public void setPickupContact(String pickupContact) {
		this.pickupContact = pickupContact;
	}

	public String getDropoffContact() {
		return dropoffContact;
	}

	public void setDropoffContact(String dropoffContact) {
		this.dropoffContact = dropoffContact;
	}

}
