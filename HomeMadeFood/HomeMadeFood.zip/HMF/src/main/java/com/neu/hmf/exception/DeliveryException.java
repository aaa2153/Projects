package com.neu.hmf.exception;

public class DeliveryException extends Exception {

	public DeliveryException(String message)
	{
		super("DeliveryException-"+message);
	}
	
	public DeliveryException(String message, Throwable cause)
	{
		super("DeliveryException-"+message,cause);
	}
	
}
