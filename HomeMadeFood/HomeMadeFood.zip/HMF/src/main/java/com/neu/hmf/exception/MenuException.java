package com.neu.hmf.exception;

public class MenuException extends Exception {

	public MenuException(String message)
	{
		super("MenuException-"+message);
	}
	
	public MenuException(String message, Throwable cause)
	{
		super("MenuException-"+message,cause);
	}
	
}
