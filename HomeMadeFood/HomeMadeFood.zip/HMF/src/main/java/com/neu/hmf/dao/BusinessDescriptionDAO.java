package com.neu.hmf.dao;

import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.BusinessDescriptionException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.BusinessDescription;

public class BusinessDescriptionDAO extends DAO {

	public BusinessDescriptionDAO() {
	}

	public List<BusinessDescription> getList() throws BusinessDescriptionException {
		try {
			begin();
			Query q = getSession().createQuery("from BusinessDescription");

			List<BusinessDescription> bdList = q.list();
			commit();

			return bdList;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Could not get description list ", e);
		}
	}

	public BusinessDescription get(User u) throws BusinessDescriptionException {
		try {
			begin();
			Query q = getSession().createQuery("from BusinessDescription where userId = :userId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("userId", (int) u.getId());
			// q.setString("password", password);
			BusinessDescription BusinessDescription = (BusinessDescription) q.uniqueResult();
			commit();

			return BusinessDescription;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Could not get BusinessDescription for " + u.getFirstname(), e);
		}
	}

	public BusinessDescription getDescription(Long bId) throws BusinessDescriptionException {
		try {
			begin();
			Query q = getSession().createQuery("from BusinessDescription where id = :bId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("bId", bId);
			// q.setString("password", password);
			BusinessDescription BusinessDescription = (BusinessDescription) q.uniqueResult();
			commit();

			return BusinessDescription;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Could not get BusinessDescription for " + bId, e);
		}
	}

	public BusinessDescription getBD(int bId) throws BusinessDescriptionException {
		try {
			begin();
			Query q = getSession().createQuery("from BusinessDescription where userId = :bId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("bId", bId);
			// q.setString("password", password);
			BusinessDescription BusinessDescription = (BusinessDescription) q.uniqueResult();
			commit();

			return BusinessDescription;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Could not get BusinessDescription for " + bId, e);
		}
	}

	public BusinessDescription register(BusinessDescription bd, User u) throws BusinessDescriptionException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			BusinessDescription businessDescription = new BusinessDescription();

			businessDescription.setBusinessName(bd.getBusinessName());
			businessDescription.setDescription(bd.getDescription());
			businessDescription.setImage(bd.getImage());
			businessDescription.setPhoto(bd.getPhoto());
			businessDescription.setYoutubeLink(bd.getYoutubeLink());
			businessDescription.setUserId((int) u.getId());
			// u.setBusinessDescription(businessDescription);

			getSession().save(businessDescription);
			commit();
			return businessDescription;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Exception while creating BusinessDescription: " + e.getMessage());
		}
	}

	public BusinessDescription updateDescription(BusinessDescription bd, User u) throws BusinessDescriptionException {
		try {

			System.out.println("inside DAO");

			BusinessDescription businessDescription = get(u);

			businessDescription.setBusinessName(bd.getBusinessName());
			businessDescription.setDescription(bd.getDescription());
			businessDescription.setImage(bd.getImage());
			businessDescription.setPhoto(bd.getPhoto());
			businessDescription.setYoutubeLink(bd.getYoutubeLink());
			// businessDescription.setUserId(bd.getUserId());

			getSession().update(businessDescription);
			begin();
			commit();
			return businessDescription;

		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException("Exception while creating BusinessDescription: " + e.getMessage());
		}
	}

	public void delete(BusinessDescription BusinessDescription) throws BusinessDescriptionException {
		try {
			begin();
			getSession().delete(BusinessDescription);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new BusinessDescriptionException(
					"Could not delete BusinessDescription " + BusinessDescription.getBusinessName(), e);
		}
	}
}