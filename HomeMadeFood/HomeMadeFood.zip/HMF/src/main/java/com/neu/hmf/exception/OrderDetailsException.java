package com.neu.hmf.exception;

public class OrderDetailsException extends Exception {

	public OrderDetailsException(String message)
	{
		super("OrderDetailsException-"+message);
	}
	
	public OrderDetailsException(String message, Throwable cause)
	{
		super("OrderDetailsException-"+message,cause);
	}
	
}
