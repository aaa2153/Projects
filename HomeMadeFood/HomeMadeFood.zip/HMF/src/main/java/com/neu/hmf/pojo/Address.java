package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "Address")
@Inheritance(strategy = InheritanceType.JOINED)
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "AddressId", unique = true, nullable = false)
	private long id;

	@Pattern(regexp = "[a-zA-Z0-9 ]*$", message = "Please enter alphanumeric characters only")
	@Column(name = "Street1")
	private String street1;

	@Pattern(regexp = "[a-zA-Z0-9 ]*$", message = "Please enter alphanumeric characters only")
	@Column(name = "Street2")
	private String street2;

	@Pattern(regexp = "[a-zA-Z ]*$", message = "Please enter alphabets only")
	@Column(name = "City")
	private String city;

	@Pattern(regexp = "[a-zA-Z ]*$", message = "Please enter alphabets only")
	@Column(name = "State")
	private String state;

	@Pattern(regexp = "[a-zA-Z ]*$", message = "Please enter alphabets only")
	@Column(name = "Country")
	private String country;

	@Pattern(regexp = "[0-9]{5}$", message = "Please enter valid zip code")
	@Column(name = "Zip")
	private String zip;

	public Address() {
	}

	public long getId() {
		return id;
	}

	public String getStreet1() {
		return street1;
	}

	public void setStreet1(String street1) {
		this.street1 = street1;
	}

	public String getStreet2() {
		return street2;
	}

	public void setStreet2(String street2) {
		this.street2 = street2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

}