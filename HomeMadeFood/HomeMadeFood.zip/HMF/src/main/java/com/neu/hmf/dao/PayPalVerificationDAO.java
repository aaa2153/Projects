package com.neu.hmf.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.PayPalVerificationException;
import com.neu.hmf.pojo.PayPalVerification;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PayPalVerificationDAO extends DAO {

	public PayPalVerificationDAO() {
	}

	public PayPalVerification get(String email, String password) throws PayPalVerificationException {
		try {
			begin();
			Query q = getSession().createQuery("from PayPalVerification where email = :email");
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			// String hashedPassword = passwordEncoder.encode(password);
			q.setString("email", email);
			// q.setString("password", password);
			PayPalVerification ppv = (PayPalVerification) q.uniqueResult();
			commit();
			if (ppv != null) {
				if (passwordEncoder.matches(password, ppv.getPassword())) {
					return ppv;
				}
			}
			return null;
		} catch (HibernateException e) {
			rollback();
			throw new PayPalVerificationException("Could not get user " + email, e);
		}
	}

}