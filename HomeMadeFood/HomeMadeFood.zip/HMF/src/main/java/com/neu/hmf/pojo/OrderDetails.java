package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "OrderDetails")
public class OrderDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "OrderDetailsId", unique = true, nullable = false)
	private long id;

	@Column(name = "MenuItem")
	private long menuItem;

	@Column(name = "Price")
	private float price;

	@Column(name = "Quantity")
	private int quantity;

	@Column(name = "Total")
	private float total;

	@Column(name = "OrderId")
	private int orderId;

	@Transient
	private String itemName;

	public OrderDetails() {

	}

	public OrderDetails(int menuItem, float price, int qty, float total, int orderId) {

		this.menuItem = menuItem;
		this.price = price;
		this.quantity = qty;
		this.total = total;
		this.orderId = orderId;
	}

	public long getId() {
		return id;
	}

	public long getMenuItem() {
		return menuItem;
	}

	public void setMenuItem(long menuItem) {
		this.menuItem = menuItem;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public float getTotal() {
		return total;
	}

	public void setTotal(float total) {
		this.total = total;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

}
