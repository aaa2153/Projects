package com.neu.hmf.pojo;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "Review")
public class Review {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ReviewId", unique = true, nullable = false)
	private long id;

	@Column(name = "Rating")
	private int rating;

	@Column(name = "Comment")
	private String comment;

	@Column(name = "PostedBy")
	private long postedBy;

	@Column(name = "Business")
	private int business;

	@Transient
	private String username;

	@Temporal(TemporalType.DATE)
	@Column(name = "Date")
	private Date date;

	public Review() {

	}

	public long getId() {
		return id;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public long getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(long postedBy) {
		this.postedBy = postedBy;
	}

	public int getBusiness() {
		return business;
	}

	public void setBusiness(int business) {
		this.business = business;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
