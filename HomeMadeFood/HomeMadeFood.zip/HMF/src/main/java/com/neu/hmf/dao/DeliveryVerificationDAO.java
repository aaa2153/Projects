package com.neu.hmf.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.DeliveryVerificationException;
import com.neu.hmf.pojo.DeliveryVerification;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class DeliveryVerificationDAO extends DAO {

	public DeliveryVerificationDAO() {
	}

	public DeliveryVerification get(String email, String password) throws DeliveryVerificationException {
		try {
			begin();
			Query q = getSession().createQuery("from DeliveryVerification where email = :email");
			BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
			q.setString("email", email);

			DeliveryVerification d = (DeliveryVerification) q.uniqueResult();
			commit();
			if (d != null) {
				if (passwordEncoder.matches(password, d.getPassword())) {
					return d;
				}
			}
			return null;
		} catch (HibernateException e) {
			rollback();
			throw new DeliveryVerificationException("Could not get user " + email, e);
		}
	}

}