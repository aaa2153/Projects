package com.neu.hmf.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.neu.hmf.dao.BusinessDescriptionDAO;
import com.neu.hmf.dao.DeliveryDAO;
import com.neu.hmf.dao.MenuDAO;
import com.neu.hmf.dao.OrderDAO;
import com.neu.hmf.dao.OrderDetailsDAO;
import com.neu.hmf.dao.ReviewDAO;
import com.neu.hmf.dao.TimingDAO;
import com.neu.hmf.dao.UserDAO;
import com.neu.hmf.exception.BusinessDescriptionException;
import com.neu.hmf.exception.MenuException;
import com.neu.hmf.exception.TimingException;
import com.neu.hmf.pojo.BusinessDescription;
import com.neu.hmf.pojo.Menu;
import com.neu.hmf.pojo.Order;
import com.neu.hmf.pojo.OrderDetails;
import com.neu.hmf.pojo.Review;
import com.neu.hmf.pojo.Timing;
import com.neu.hmf.pojo.User;
import com.neu.hmf.validator.BusinessDescriptionValidator;
import com.neu.hmf.validator.MenuValidator;
import com.neu.hmf.validator.ReviewValidator;
import com.neu.hmf.validator.TimingValidator;

@Controller
@RequestMapping("/business/*")
public class BusinessController {

	private Validator vd;

	public BusinessController() {
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		vd = validatorFactory.getValidator();
	}

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

	@Autowired
	@Qualifier("bdDao")
	BusinessDescriptionDAO bdDao;

	@Autowired
	@Qualifier("menuDao")
	MenuDAO menuDao;

	@Autowired
	@Qualifier("reviewDao")
	ReviewDAO reviewDao;

	@Autowired
	@Qualifier("timingDao")
	TimingDAO timingDao;

	@Autowired
	ServletContext servletContext;

	@Autowired
	@Qualifier("bdValidator")
	BusinessDescriptionValidator validator;

	@Autowired
	@Qualifier("reviewValidator")
	ReviewValidator rvalidator;

	@Autowired
	@Qualifier("menuValidator")
	MenuValidator mvalidator;

	@Autowired
	@Qualifier("timeValidator")
	TimingValidator tvalidator;

	@Autowired
	@Qualifier("orderDao")
	OrderDAO orderDao;

	@Autowired
	@Qualifier("orderDetailsDao")
	OrderDetailsDAO orderDetailsDao;

	@Autowired
	@Qualifier("deliveryDao")
	DeliveryDAO deliveryDao;

	@InitBinder("businessDescription")
	private void initDescriptionBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@InitBinder("menu")
	private void initMenuBinder(WebDataBinder binder) {
		binder.setValidator(mvalidator);
	}

	@InitBinder("review")
	private void initReviewBinder(WebDataBinder binder) {
		binder.setValidator(rvalidator);
	}

	@InitBinder("timing")
	private void initTimingBinder(WebDataBinder binder) {
		binder.setValidator(tvalidator);
	}

	@RequestMapping(value = "/business/", method = RequestMethod.GET)
	protected ModelAndView manageBusiness(HttpServletRequest request) throws Exception {

		HttpSession session = request.getSession();

		User u = (User) session.getAttribute("user");

		BusinessDescription bdesc = bdDao.get(u);

		if (bdesc != null) {

			List<Review> reviewList = reviewDao.getAllReviews(bdesc.getUserId());

			if (reviewList.size() != 0) {

				int rating = 0;

				for (Review review : reviewList) {

					rating += review.getRating();

				}

				bdesc.setTotalRating(rating / reviewList.size());

				bdesc.setReviewCount(reviewList.size());
			}

			List<Menu> menuList = null;
			List<Review> reviews = reviewDao.get(u);

			List<Order> orderList = orderDao.getBusinessOrderList(u);

			if (orderList != null) {

				List<List<OrderDetails>> orderDetailsList = new ArrayList<List<OrderDetails>>();

				for (Order order : orderList) {

					orderDetailsList.add(orderDetailsDao.getOrderDetails(order.getId()));

				}

				session.setAttribute("businessReviews", reviews);
				session.setAttribute("orderDetails", orderDetailsList);
			}
			menuList = menuDao.get(u);
			// reviews= reviewDao.get(u);

			request.setAttribute("menu", new Menu());

			Timing time = timingDao.getTiming(u);

			if (time != null) {
				request.setAttribute("timing", time);
			} else {
				request.setAttribute("timing", new Timing());
			}

			// if(reviews!=null)
			// {
			// request.setAttribute("reviews", reviews);
			// }
			//
			// else
			// {
			request.setAttribute("reviews", new ArrayList<Review>());
			// }

			// request.setAttribute("timing", new Timing());

			// Timing time= timingDao.getTiming(u);

			if (menuList != null) {
				request.setAttribute("menuList", menuList);
			}

			else {
				request.setAttribute("menuList", new ArrayList<Menu>());
			}

			// if(bdesc!=null)
			// {
			request.setAttribute("businessDescription", bdesc);
			// }
			//
			// else
			// {
			// request.setAttribute("businessDescription",new
			// BusinessDescription());
			// }

			return new ModelAndView("manageBusiness", "businessDescription", bdesc);

		}

		request.setAttribute("menu", new Menu());

		request.setAttribute("timing", new Timing());

		request.setAttribute("reviews", new ArrayList<Review>());

		request.setAttribute("menuList", new ArrayList<Menu>());

		request.setAttribute("businessDescription", new BusinessDescription());

		return new ModelAndView("manageBusiness", "businessDescription", new BusinessDescription());

	}

	@RequestMapping(value = "/business/description", method = RequestMethod.POST)
	protected String businessDescription(HttpServletRequest request,
			@ModelAttribute("businessDescription") BusinessDescription bd, BindingResult result) throws Exception {

		HttpSession session = request.getSession();
		boolean success = false;
		validator.validate(bd, result);

		if (result.hasErrors()) {
			return "redirect:/business/";
		}

		try {
			if (bd.getImage().trim() != "" || bd.getImage() != null) {
				File directory;
				String check = File.separator; // Checking if system is linux
												// based or windows based by
												// checking seprator used.
				String path = null;
				if (check.equalsIgnoreCase("\\")) {
					path = servletContext.getRealPath("").replace("build\\", "");
				}

				if (check.equalsIgnoreCase("/")) {
					path = servletContext.getRealPath("").replace("build/", "");
					path += "/"; // Adding trailing slash for Mac systems.
				}
				directory = new File(path + "\\" + bd.getImage());
				boolean temp = directory.exists();
				if (!temp) {
					temp = directory.mkdir();
				}
				if (temp) {
					// We need to transfer to a file
					CommonsMultipartFile photoInMemory = bd.getPhoto();

					String fileName = photoInMemory.getOriginalFilename();
					// could generate file names as well

					File localFile = new File(directory.getPath(), fileName);

					// move the file from memory to the file

					photoInMemory.transferTo(localFile);
					bd.setImage(fileName);
					System.out.println("File is stored at" + localFile.getPath());
					// System.out.print("registerNewUser");
					// User u = userDao.register(user);

				} else {
					System.out.println("Failed to create directory!");
				}
			}

		} catch (IllegalStateException e) {
			System.out.println("*** IllegalStateException: " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("*** IOException: " + e.getMessage());
		}

		try {

			System.out.print("registerNewUser");

			User u = (User) session.getAttribute("user");

			BusinessDescription bdesc = bdDao.get(u);

			if (bdesc == null) {
				BusinessDescription b = bdDao.register(bd, u);
				bdesc = b;
			}

			else {
				BusinessDescription b = bdDao.updateDescription(bd, u);
				bdesc = b;
			}

			// request.getSession().setAttribute("user", u);

			// session.setAttribute("businessDescription", bdesc);
			//
			// Menu menu=(Menu)session.getAttribute("menu");
			// request.setAttribute("menu", menu);

			Gson gson = new Gson();

			String jsonInString = gson.toJson(bdesc);

			// session.setAttribute("loggedIn", loggedIn);

			System.out.println(jsonInString);
			return "redirect:/business/";

			// success=true;
			// session.setAttribute("success", success);
			// return new
			// ModelAndView("manageBusiness","businessDescription",bdesc);

		} catch (BusinessDescriptionException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/business/menu", method = RequestMethod.POST)
	protected String businessMenu(HttpServletRequest request, @Valid @ModelAttribute("menu") Menu m,
			BindingResult result) throws Exception {

		Set<ConstraintViolation<Menu>> violations = vd.validate(m);

		for (ConstraintViolation<Menu> violation : violations) {
			String propertyPath = violation.getPropertyPath().toString();
			String message = violation.getMessage();
			// Add JSR-303 errors to BindingResult
			// This allows Spring to display them in view via a FieldError
			result.addError(new FieldError("user", propertyPath,

					"Invalid " + propertyPath + "(" + message + ")"));
		}

		HttpSession session = request.getSession();
		boolean success = false;
		mvalidator.validate(m, result);

		if (result.hasErrors()) {
			return "redirect:/business/";
		}

		try {
			if (m.getImage().trim() != "" || m.getImage() != null) {
				File directory;
				String check = File.separator; // Checking if system is linux
												// based or windows based by
												// checking seprator used.
				String path = null;
				if (check.equalsIgnoreCase("\\")) {
					path = servletContext.getRealPath("").replace("build\\", "");
				}

				if (check.equalsIgnoreCase("/")) {
					path = servletContext.getRealPath("").replace("build/", "");
					path += "/"; // Adding trailing slash for Mac systems.
				}
				directory = new File(path + "\\" + m.getImage());
				boolean temp = directory.exists();
				if (!temp) {
					temp = directory.mkdir();
				}
				if (temp) {
					// We need to transfer to a file
					CommonsMultipartFile photoInMemory = m.getPhoto();

					String fileName = photoInMemory.getOriginalFilename();
					// could generate file names as well

					File localFile = new File(directory.getPath(), fileName);

					// move the file from memory to the file

					photoInMemory.transferTo(localFile);
					m.setImage(fileName);
					System.out.println("File is stored at" + localFile.getPath());
					// System.out.print("registerNewUser");
					// User u = userDao.register(user);

				} else {
					System.out.println("Failed to create directory!");
				}
			}

		} catch (IllegalStateException e) {
			System.out.println("*** IllegalStateException: " + e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("*** IOException: " + e.getMessage());
		}

		try {

			System.out.print("registerNewUser");

			User u = (User) session.getAttribute("user");

			Menu mn = menuDao.add(m, u);

			List<Menu> menu;

			menu = menuDao.get(u);

			// request.getSession().setAttribute("user", u);

			// session.setAttribute("menu", mn);
			//
			// BusinessDescription
			// bd=(BusinessDescription)session.getAttribute("businessDescription");
			// request.setAttribute("businessDescription", bd);
			//
			// success=true;
			// session.setAttribute("success", success);
			// return new ModelAndView("manageBusiness","menuList",menu);
			Gson gson = new Gson();

			String jsonInString = gson.toJson(menu);

			// session.setAttribute("loggedIn", loggedIn);

			System.out.println(jsonInString);
			return "redirect:/business/";

		} catch (MenuException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/menu/remove", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	protected String removeItem(@RequestParam("itemId") long itemId, HttpServletRequest request,
			@ModelAttribute("menu") Menu m, BindingResult result) throws Exception {

		try {

			System.out.print("registerNewUser");

			Menu menu = menuDao.getMenuItem(itemId);

			Gson gson = new Gson();

			String jsonString = gson.toJson(menu);

			menuDao.delete(menu);

			System.out.println("success");

			return jsonString;

		} catch (MenuException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/business/timing", method = RequestMethod.POST)
	protected String manageTime(HttpServletRequest request, @ModelAttribute("timing") Timing t, BindingResult result)
			throws Exception {

		HttpSession session = request.getSession();

		try {

			User u = (User) session.getAttribute("user");

			System.out.print("registerNewUser");

			Timing time = timingDao.getTiming(u);

			if (time == null) {
				timingDao.addTiming(t, u);
				// bdesc=b;
			}

			else {
				time = timingDao.updateTiming(t, u);
				// bdesc=b;
			}

			// Timing time=timingDao.getTiming(u);

			Gson gson = new Gson();

			String jsonInString = gson.toJson(time);

			System.out.println("success");
			return "redirect:/business/";

		} catch (TimingException e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

	@RequestMapping(value = "/business/dispatchOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	protected String checkout(@RequestParam("orderId") long orderId, HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		try {

			Order order = orderDao.getOrder(orderId);

			orderDao.updateOrderStatus(order);

			User business = userDao.get(order.getBusiness());

			User customer = userDao.get(order.getCustomer());

			String businessAddress = business.getStreet1().replaceAll(" ", "+") + "+" + business.getCity() + ",+"
					+ business.getState();

			User driver = userDao.getDriver(businessAddress);

			deliveryDao.addOrder(business, customer, driver, order);

			Gson gson = new Gson();

			String jsonString = gson.toJson(order);

			return jsonString;

		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			return "error";
		}
	}

}
