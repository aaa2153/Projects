package com.neu.hmf.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.hmf.pojo.Review;
import com.neu.hmf.pojo.Timing;

public class TimingValidator implements Validator {

	public boolean supports(Class aClass) {
		return aClass.equals(Timing.class);
	}

	public void validate(Object obj, Errors errors) {
		Timing timing = (Timing) obj;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "openingTime", "error.invalid.timing",
				"Opening Time Required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "closingTime", "error.invalid.timing",
				"Closing Time Required");

	}
}
