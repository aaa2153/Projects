package com.neu.hmf.exception;

public class PayPalVerificationException extends Exception {

	public PayPalVerificationException(String message)
	{
		super("PayPalVerificationException-"+message);
	}
	
	public PayPalVerificationException(String message, Throwable cause)
	{
		super("PayPalVerificationException-"+message,cause);
	}
	
}
