package com.neu.hmf.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.neu.hmf.pojo.Review;

public class ReviewValidator implements Validator {

	public boolean supports(Class aClass) {
		return aClass.equals(Review.class);
	}

	public void validate(Object obj, Errors errors) {
		Review review = (Review) obj;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "rating", "error.invalid.review", "Item Name Required");
		// ValidationUtils.rejectIfEmptyOrWhitespace(errors, "comment",
		// "error.invalid.review", "Item description Required");

	}
}
