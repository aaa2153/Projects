package com.neu.hmf.dao;

import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.ReviewException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.Review;

public class ReviewDAO extends DAO {

	public ReviewDAO() {
	}

	public List<Review> get(User u) throws ReviewException {
		try {
			begin();
			Query q = getSession().createQuery("from Review where business = :userId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setInteger("userId", (int) u.getId());
			// q.setString("password", password);
			List<Review> reviews = q.list();

			for (Review review : reviews) {

				Query q1 = getSession().createQuery(
						"select concat(u.firstname, ' ', u.lastname) as fullname from User u INNER JOIN Review r ON  r.postedBy=u.id where r.id= :reviewId");

				q1.setLong("reviewId", review.getId());

				String username = (String) q1.uniqueResult();

				review.setUsername(username);

			}

			commit();

			return reviews;

		} catch (HibernateException e) {
			rollback();
			throw new ReviewException("Could not get reviews for " + u.getFirstname(), e);
		}
	}

	public List<Review> getAllReviews(int businessId) throws ReviewException {
		try {
			begin();
			Query q = getSession().createQuery("from Review where business= :businessId");

			// String hashedPassword = passwordEncoder.encode(password);
			q.setInteger("businessId", businessId);
			// q.setInteger("userId", (int)u.getId());
			// q.setString("password", password);
			List<Review> reviews = q.list();

			for (Review review : reviews) {

				Query q1 = getSession().createQuery(
						"select concat(u.firstname, ' ', u.lastname) as fullname from User u INNER JOIN Review r ON  r.postedBy=u.id where r.id= :reviewId");

				q1.setLong("reviewId", review.getId());

				String username = (String) q1.uniqueResult();

				review.setUsername(username);

			}

			commit();

			return reviews;

		} catch (HibernateException e) {
			rollback();
			throw new ReviewException("Could not get all reviews", e);
		}
	}

	public Review add(int rating, String comment, User business, User customer) throws ReviewException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			Review review = new Review();

			review.setBusiness((int) business.getId());
			review.setComment(comment);
			review.setPostedBy(customer.getId());
			review.setRating(rating);
			// review.setUsername(customer.getFirstname()+"
			// "+customer.getLastname());
			review.setDate(new Date());

			// u.setBusinessDescription(businessDescription);

			getSession().save(review);
			commit();
			return review;

		} catch (HibernateException e) {
			rollback();
			throw new ReviewException("Exception while creating Review: " + e.getMessage());
		}
	}

	public void delete(Review review) throws ReviewException {
		try {
			begin();
			getSession().delete(review);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new ReviewException("Could not delete Review By " + review.getPostedBy(), e);
		}
	}
}