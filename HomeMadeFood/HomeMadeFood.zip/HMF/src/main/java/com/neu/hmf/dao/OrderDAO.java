package com.neu.hmf.dao;

import java.util.Date;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.neu.hmf.exception.OrderException;
import com.neu.hmf.pojo.User;
import com.neu.hmf.pojo.Order;

public class OrderDAO extends DAO {

	public OrderDAO() {
	}

	public List<Order> getBusinessOrderList(User u) throws OrderException {
		try {
			begin();
			Query q = getSession().createQuery("from Order where business = :businessId and status= :status");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("businessId", u.getId());
			q.setString("status", "Being Prepared");
			// q.setString("password", password);
			// Order order = (Order) q.uniqueResult();

			List<Order> orderList = q.list();

			commit();

			return orderList;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Could not get Item", e);
		}
	}

	public List<Order> getCustomerOrderList(User u) throws OrderException {
		try {
			begin();
			Query q = getSession().createQuery("from Order where customer = :customerId and status= :status");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("customerId", u.getId());
			q.setString("status", "Delivered");
			// q.setString("password", password);
			// Order order = (Order) q.uniqueResult();

			List<Order> orderList = q.list();

			commit();

			return orderList;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Could not get Item", e);
		}
	}

	public Order getOrder(long orderId) throws OrderException {
		try {
			begin();
			Query q = getSession().createQuery("from Order where id = :orderId");

			// String hashedPassword = passwordEncoder.encode(password);
			// q.setString("user", u);
			q.setLong("orderId", orderId);
			// q.setString("password", password);
			// Order order = (Order) q.uniqueResult();

			// List<Order> orderList=q.list();

			Order order = (Order) q.uniqueResult();

			commit();

			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Could not get Item", e);
		}
	}

	public Order placeOrder(int customer, int business, float amount) throws OrderException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			Order order = new Order();

			order.setAmount(amount);
			order.setBusiness(business);
			order.setCustomer(customer);
			order.setDate(new Date());
			order.setStatus("Being Prepared");
			// u.setBusinessDescription(businessDescription);

			getSession().save(order);
			commit();
			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Exception while placing Order: " + e.getMessage());
		}
	}

	public Order updateOrder(Order order, float amount) throws OrderException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Order order = new Order();

			order.setAmount(amount);

			// u.setBusinessDescription(businessDescription);

			getSession().update(order);
			commit();
			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Exception while updating Order: " + e.getMessage());
		}
	}

	public Order updateOrderStatus(Order order) throws OrderException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Order order = new Order();

			order.setStatus("Ready for Delivery");

			// u.setBusinessDescription(businessDescription);

			getSession().update(order);
			commit();
			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Exception while updating Order: " + e.getMessage());
		}
	}

	public Order updateOrderStatusPick(Order order) throws OrderException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Order order = new Order();

			order.setStatus("Picked Up");

			// u.setBusinessDescription(businessDescription);

			getSession().update(order);
			commit();
			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Exception while updating Order: " + e.getMessage());
		}
	}

	public Order updateOrderStatusDrop(Order order) throws OrderException {
		try {
			begin();
			System.out.println("inside DAO");

			// Address address = new
			// Address(u.getAddress().getStreet1(),u.getAddress().getStreet2(),u.getAddress().getCity(),u.getAddress().getState(),u.getAddress().getCountry(),u.getAddress().getZip());
			// Set<Role> roles = u.getRoles();

			// Order order = new Order();

			order.setStatus("Delivered");

			// u.setBusinessDescription(businessDescription);

			getSession().update(order);
			commit();
			return order;

		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Exception while updating Order: " + e.getMessage());
		}
	}

	public void delete(Order order) throws OrderException {
		try {
			begin();
			getSession().delete(order);
			commit();
		} catch (HibernateException e) {
			rollback();
			throw new OrderException("Could not delete Order " + order.getId(), e);
		}
	}
}