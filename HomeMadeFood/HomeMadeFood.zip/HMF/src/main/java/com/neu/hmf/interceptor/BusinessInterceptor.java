package com.neu.hmf.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.neu.hmf.pojo.User;

public class BusinessInterceptor extends HandlerInterceptorAdapter {

	String errorPage;

	public String getErrorPage() {
		return errorPage;
	}

	public void setErrorPage(String errorPage) {
		this.errorPage = errorPage;
	}

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		if (session.getAttribute("user") != null) {

			User u = (User) session.getAttribute("user");

			if (u.getRole().getBusiness() == 1) {
				return true;
			}

			else {
				System.out.println("unauthorized user");
				response.sendRedirect(errorPage);
				return false;
			}
		}

		System.out.println("no user");
		response.sendRedirect(errorPage);
		return false;

	}

}