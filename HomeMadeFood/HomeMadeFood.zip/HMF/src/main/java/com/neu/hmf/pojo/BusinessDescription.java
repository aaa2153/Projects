package com.neu.hmf.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

@Entity
@Table(name = "BusinessDescription")
public class BusinessDescription {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "DescriptionId", unique = true, nullable = false)
	private long id;

	// @Size(max=30,message="max limit 30 characters")
	@Column(name = "BusinessName")
	private String businessName;

	// @Size(max=180,message="max limit 180 characters")
	@Column(name = "Description")
	private String description;

	@Transient
	private CommonsMultipartFile photo;

	@Column(name = "Image")
	private String image;

	// @Pattern(regexp="[a-zA-Z]*$",message="Please enter alphabets only")
	// @Size(max=34,message="max limit 34 characters")
	@Column(name = "YoutubeLink")
	private String youtubeLink;

	// @OneToOne(cascade = CascadeType.ALL)
	// @JoinColumn(name = "UserId")
	// private User user1;

	@Column(name = "UId")
	private int userId;

	@Transient
	private int totalRating;

	@Transient
	private int reviewCount;

	@Transient
	private String openingTime;

	@Transient
	private String closingTime;

	// public User(String email, String password) {
	// this.email = email;
	// this.password = password;
	// }

	public BusinessDescription() {

	}

	public long getId() {
		return id;
	}

	public CommonsMultipartFile getPhoto() {
		return photo;
	}

	public void setPhoto(CommonsMultipartFile photo) {
		this.photo = photo;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getYoutubeLink() {
		return youtubeLink;
	}

	public void setYoutubeLink(String youtubeLink) {
		this.youtubeLink = youtubeLink;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public int getTotalRating() {
		return totalRating;
	}

	public void setTotalRating(int totalRating) {
		this.totalRating = totalRating;
	}

	public int getReviewCount() {
		return reviewCount;
	}

	public void setReviewCount(int reviewCount) {
		this.reviewCount = reviewCount;
	}

	public String getOpeningTime() {
		return openingTime;
	}

	public void setOpeningTime(String openingTime) {
		this.openingTime = openingTime;
	}

	public String getClosingTime() {
		return closingTime;
	}

	public void setClosingTime(String closingTime) {
		this.closingTime = closingTime;
	}

}
