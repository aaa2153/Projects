package com.neu.hmf.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.ConstraintViolation;
import javax.validation.Valid;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.neu.hmf.dao.OrderDAO;
import com.neu.hmf.dao.OrderDetailsDAO;
import com.neu.hmf.dao.UserDAO;
import com.neu.hmf.exception.UserException;
import com.neu.hmf.pojo.Order;
import com.neu.hmf.pojo.OrderDetails;
import com.neu.hmf.pojo.User;
import com.neu.hmf.validator.UserValidator;
//import com.neu.hmf.validator.UserValidator;

@Controller
@RequestMapping("/account/*")
public class UserController {

	private Validator vd;

	public UserController() {
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		vd = validatorFactory.getValidator();
	}

	@Autowired
	@Qualifier("userDao")
	UserDAO userDao;

	@Autowired
	@Qualifier("orderDao")
	OrderDAO orderDao;

	@Autowired
	@Qualifier("orderDetailsDao")
	OrderDetailsDAO orderDetailsDao;

	@Autowired
	@Qualifier("userValidator")
	UserValidator validator;

	@InitBinder
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@RequestMapping(value = "/account/login", method = RequestMethod.GET)
	protected String goToUserHome(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		Boolean loggedIn = (Boolean) session.getAttribute("loggedIn");
		if (loggedIn != null) {
			if (loggedIn == true) {
				return "redirect:/account/";
			}
		}

		return "login";
	}

	@RequestMapping(value = "/account/", method = RequestMethod.GET)
	protected String userAccount(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();

		User u = (User) session.getAttribute("user");

		List<Order> orderList = orderDao.getCustomerOrderList(u);

		List<List<OrderDetails>> orderDetailsList = new ArrayList<List<OrderDetails>>();

		for (Order order : orderList) {

			orderDetailsList.add(orderDetailsDao.getOrderDetails(order.getId()));

		}

		session.setAttribute("customerOrder", orderDetailsList);

		Boolean loggedIn = (Boolean) session.getAttribute("loggedIn");
		if (loggedIn != null) {
			if (loggedIn == true) {
				System.out.println(request.getRequestURL());
				return "account";

			}
		}
		return "redirect:/account/login";
	}

	@RequestMapping(value = "/account/error", method = RequestMethod.GET)
	protected String error(HttpServletRequest request) throws Exception {
		return "error";
	}

	@RequestMapping(value = "/account/logout", method = RequestMethod.GET)
	protected String logout(HttpServletRequest request) throws Exception {
		HttpSession session = (HttpSession) request.getSession();
		session.invalidate();
		return "redirect:/";
	}

	@RequestMapping(value = "/account/login", method = RequestMethod.POST)
	protected String loginUser(HttpServletRequest request) throws Exception {

		HttpSession session = (HttpSession) request.getSession();
		boolean loggedIn = true;
		boolean business = false;
		boolean delivery = false;
		boolean loginError = false;

		try {

			System.out.print("loginUser");

			User u = userDao.get(request.getParameter("email"), request.getParameter("password"));

			if (u == null) {
				loggedIn = false;
				loginError = true;
				System.out.println("UserName/Password does not exist");
				session.setAttribute("loginError", loginError);
				return "redirect:/account/error";
			}

			if (u.getRole().getBusiness() == 1) {
				business = true;
			}

			if (u.getRole().getDelivery() == 1) {
				delivery = true;
			}

			session.setAttribute("loggedIn", loggedIn);
			session.setAttribute("business", business);
			session.setAttribute("delivery", delivery);
			session.setAttribute("user", u);

			return "redirect:/account/";

		} catch (UserException e) {
			System.out.println("Exception: " + e.getMessage());
			session.setAttribute("errorMessage", "error while login");
			return "redirect:/account/error";
		}

	}

	@RequestMapping(value = "/account/register", method = RequestMethod.GET)
	protected ModelAndView registerUser() throws Exception {
		System.out.print("registerUser");

		return new ModelAndView("register", "user", new User());

	}

	@RequestMapping(value = "/account/register", method = RequestMethod.POST)
	protected ModelAndView registerNewUser(HttpServletRequest request, @Valid @ModelAttribute("user") User user,
			BindingResult result) throws Exception {

		HttpSession session = request.getSession();
		boolean success = false;

		boolean unique = true;

		// validator.validate(user, result);

		Set<ConstraintViolation<User>> violations = vd.validate(user);

		for (ConstraintViolation<User> violation : violations) {
			String propertyPath = violation.getPropertyPath().toString();
			String message = violation.getMessage();
			// Add JSR-303 errors to BindingResult
			// This allows Spring to display them in view via a FieldError
			result.addError(new FieldError("user", propertyPath,

					"Invalid " + propertyPath + "(" + message + ")"));
		}

		if (result.hasErrors()) {
			return new ModelAndView("register", "user", user);
		}

		try {

			System.out.print("registerNewUser");

			User u = userDao.register(user);

			request.getSession().setAttribute("user", u);

			success = true;
			session.setAttribute("success", success);
			return new ModelAndView("register");

		} catch (UserException e) {
			System.out.println("Exception: " + e.getMessage());
			unique = false;
			session.setAttribute("unique", unique);
			return new ModelAndView("error", "errorMessage", "error while login");
		}
	}

}
